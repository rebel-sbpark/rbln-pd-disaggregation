#!/usr/bin/env bash
# GPU prefill producer — prefill on the GPU, bridge KV to the RBLN layout/dtype, publish to the NPU
# decode pool over pd_nixl. Model-agnostic: MODEL and the RBLN KV geometry are supplied by the caller
# (geometry is read from the consumer artifact via --rbln-config, or passed explicitly).
#   MODEL=<hf-id> CONSUMER_IP=<npu-ip> RBLN_CONFIG=/path/to/decodepool-artifact bash run_producer_gpu.sh
set -euo pipefail
VENV="${VENV:-/workspace/gpuenv}"                # a CUDA venv on the GPU box
MODEL="${MODEL:?set MODEL (HF id/path; must match the consumer artifact)}"
CONSUMER_IP="${CONSUMER_IP:?set CONSUMER_IP (NPU decoder pd_nixl host)}"
CONSUMER_PORT="${CONSUMER_PORT:-9000}"
export UCX_TLS="${UCX_TLS:-cma,tcp,self}"        # match the consumer's transport

GEOM=()
if [ -n "${RBLN_CONFIG:-}" ]; then
  GEOM=(--rbln-config "$RBLN_CONFIG")            # read kv_heads/block/head_dim/layers from the artifact
else
  GEOM=(--kv-heads "${KV_HEADS:?set RBLN_CONFIG or KV_HEADS/BLOCK_SIZE/HEAD_DIM/NUM_LAYERS}" \
        --block-size "$BLOCK_SIZE" --head-dim "$HEAD_DIM" --num-layers "$NUM_LAYERS")
fi

"$VENV/bin/python" gpu_prefill_producer.py \
  --model "$MODEL" --consumer-host "$CONSUMER_IP" --consumer-port "$CONSUMER_PORT" \
  --kv-dtype "${KV_DTYPE:-float16}" --prompt "${PROMPT:-The capital of France is}" "${GEOM[@]}"
