"""RoPE convention for the KV bridge.

The RBLN KV cache stores **post-RoPE K** using the model's own rotary convention. When the producer
(GPU/HF) caches K with the same convention (e.g. standard NeoX `rotate_half`, matching head order and
position indexing), the bridge does **recode (dlfloat16) + retile (RBLN block layout) ONLY — it does
NOT re-apply RoPE**. This holds for model families where the framework caches post-RoPE K identically
on both sides; **verify it per model family** before trusting the pipeline.

This module provides:
  - `apply_neox_rope` — an independent NeoX rotary implementation (for models that use it), so the
    transform is explicit and unit-testable rather than only trusted from a framework cache;
  - `verify_matches_rbln` — a producer-side guard that compares the producer's post-RoPE K against a
    reference K fetched from the NPU, so convention/dtype parity is asserted on the first request.
"""
from __future__ import annotations

import numpy as np


def apply_neox_rope(x_pre: np.ndarray, cos: np.ndarray, sin: np.ndarray) -> np.ndarray:
    """Standard HF NeoX rotary. x_pre: [..., seq, head_dim] (post qk-norm, pre-RoPE).
    cos/sin: [seq, head_dim] (each half duplicated, as HF emits). Returns post-RoPE, same shape.
        rotate_half(x) = concat(-x[d/2:], x[:d/2]);  out = x*cos + rotate_half(x)*sin
    """
    d = x_pre.shape[-1]
    x1, x2 = x_pre[..., : d // 2], x_pre[..., d // 2 :]
    rot = np.concatenate([-x2, x1], axis=-1)
    # broadcast cos/sin over head axis: x_pre is [heads, seq, d], cos is [seq, d]
    return x_pre * cos[..., :, :] + rot * sin[..., :, :]


def verify_matches_rbln(producer_post_rope_k: np.ndarray, npu_reference_k: np.ndarray,
                        cos_thresh: float = 0.999, rel_thresh: float = 0.02) -> dict:
    """Producer guard: assert the producer's post-RoPE K matches the NPU's cached K to dlfloat
    precision. Returns {'ok', 'cos', 'rel'}. Run on the first request before trusting the bridge."""
    a = producer_post_rope_k.reshape(-1).astype(np.float64)
    b = npu_reference_k.reshape(-1).astype(np.float64)
    cos = float(np.dot(a, b) / (np.linalg.norm(a) * np.linalg.norm(b) + 1e-12))
    rel = float(np.abs(a - b).mean() / (np.abs(b).mean() + 1e-12))
    return {"ok": cos >= cos_thresh and rel <= rel_thresh, "cos": cos, "rel": rel}
