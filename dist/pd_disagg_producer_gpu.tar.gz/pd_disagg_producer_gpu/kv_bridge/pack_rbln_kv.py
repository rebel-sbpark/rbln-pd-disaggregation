"""pack_rbln_kv — retile a producer's KV into the RBLN per-layer block layout + dlfloat16.

RBLN per-named-tensor layout (from rbln_config.kvcache_metas):
    past_key_values_{2i}   = layer i K,   shape [num_blocks, kv_heads, block_size, head_dim]
    past_key_values_{2i+1} = layer i V,   same shape
    dtype on device = dlfloat16 (2 B). The _update/_fetch boundary is the MERGED all-heads tensor;
    the runtime shards across TP ranks INTERNALLY. So the producer does NOT hand-shard by TP; it
    produces the canonical merged [kv_heads, block_size, head_dim] block and the runtime distributes it.

Producer K/V come in as [kv_heads, seq_len, head_dim] fp32 (post-RoPE K, raw V — RoPE already applied
by the producer's model; see rope_align). This module places the valid tokens into a block and recodes
to dlfloat16 uint16, ready to drop into a _update_kv_cache host pool row.
"""
from __future__ import annotations

import numpy as np

from .dlfloat import float32_to_dlfloat16


def pack_layer_block(kv_hLd: np.ndarray, block_size: int, kv_heads: int, head_dim: int) -> np.ndarray:
    """[kv_heads, seq_len<=block_size, head_dim] fp32 -> flat uint16 dlfloat16 of one block
    [kv_heads, block_size, head_dim], valid tokens placed at 0..seq_len-1, rest zero.
    Returns shape [kv_heads*block_size*head_dim] (the per_layer_numel a _update pool row expects)."""
    h, L, d = kv_hLd.shape
    assert h == kv_heads and d == head_dim, f"got {kv_hLd.shape}, expected heads={kv_heads} dim={head_dim}"
    assert L <= block_size, f"seq_len {L} > block_size {block_size}"
    block = np.zeros((kv_heads, block_size, head_dim), dtype=np.float32)
    block[:, :L, :] = kv_hLd.astype(np.float32)
    return float32_to_dlfloat16(block.reshape(-1))  # uint16 [kv_heads*block_size*head_dim]


def tp_shard_heads(full_hLd: np.ndarray, tp: int) -> list:
    """Split the merged [kv_heads, ...] tensor into `tp` contiguous head-groups. Provided for
    completeness/inspection; NOT needed at the _update boundary (the runtime shards internally —
    the _fetch/_update tensor is the merged all-heads one). kv_heads must be divisible by tp."""
    h = full_hLd.shape[0]
    assert h % tp == 0, f"kv_heads {h} not divisible by tp {tp}"
    per = h // tp
    return [full_hLd[r * per:(r + 1) * per] for r in range(tp)]
