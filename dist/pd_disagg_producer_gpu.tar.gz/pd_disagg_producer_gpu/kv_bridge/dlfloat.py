"""Bit-exact numpy port of RBLN-CA25 dlfloat16 (1 sign / 6 exp / 9 mantissa, exp-bias 31).

Ports the canonical C++ converters in
`rebel_compiler/rebel/include/rebel/common/float_converter.h`:
  - convFloat2Dlfloat  (float32 -> dlfloat16)  ->  float32_to_dlfloat16
  - convDlfloat2Float  (dlfloat16 -> float32)  ->  dlfloat16_to_float32

Why this exists: the RBLN KV cache is PHYSICALLY dlfloat16 (2 B/elem), even though the
rbln_config metas may label it "float32". A non-RBLN producer's IEEE fp16/bf16 KV is
bit-incompatible, so it must be recoded to these exact bits before it can be written to the NPU.
This module is the numeric half of that bridge (layout/RoPE are handled separately).

dlfloat16 bit layout (matches float_converter.h):
    [15] sign | [14:9] exponent (6b, bias 31) | [8:0] mantissa (9b)
    minExp = 128 - 2^(6-1) = 96   (float32-exponent domain)
    maxExp = 96 + 2^6 - 1 = 159
No denormals (flush to signed zero); overflow / inf / nan -> max magnitude (0x7fff | sign).
"""
from __future__ import annotations

import numpy as np

NUM_MAN = 9
NUM_EXP = 6
MASK_MAN = 0x03FF            # NUM_MAN + 1 bits (keeps 1 extra for rounding)
MASK_EXP = 0x7E00            # exponent field in the 16-bit word
MIN_EXP = 128 - (1 << (NUM_EXP - 1))   # 96
MAX_EXP = MIN_EXP + (1 << NUM_EXP) - 1  # 159


def float32_to_dlfloat16(x: np.ndarray) -> np.ndarray:
    """float32 array -> uint16 array of dlfloat16 bit patterns (vectorized convFloat2Dlfloat)."""
    x = np.ascontiguousarray(x, dtype=np.float32)
    i = x.view(np.uint32)

    t1 = ((i >> 16) & 0x8000).astype(np.uint16)             # sign in bit 15
    t2 = (i >> 23) & 0x0FF                                   # 8-bit float32 exponent (uint32)
    t3 = ((i >> (22 - NUM_MAN)) & MASK_MAN).astype(np.uint16)  # 10 bits: 9 man + 1 round

    out = (t1
           | (((t2 - MIN_EXP).astype(np.uint16) << NUM_MAN) & 0xFFFF)
           | (t3 >> 1)).astype(np.uint16)

    # round to nearest: add the dropped LSB, unless the word is already all-ones (0x7fff mask)
    not_all_ones = (out & 0x7FFF) != 0x7FFF
    out = (out + ((t3 & 1) & not_all_ones.astype(np.uint16))).astype(np.uint16)

    # underflow (too small, incl. denormals): sign bit only  -> signed zero
    out = np.where(t2 < MIN_EXP, t1, out).astype(np.uint16)
    # overflow / inf / nan: max magnitude with sign
    out = np.where(t2 > MAX_EXP, (0x7FFF | t1).astype(np.uint16), out).astype(np.uint16)
    return out


def dlfloat16_to_float32(u: np.ndarray) -> np.ndarray:
    """uint16 dlfloat16 bit patterns -> float32 array (vectorized convDlfloat2Float)."""
    u = np.ascontiguousarray(u, dtype=np.uint16).astype(np.uint32)

    t1 = (u & 0x8000) << 16                       # sign
    t3 = (u & (MASK_MAN >> 1)) << (23 - NUM_MAN)  # 9-bit mantissa -> float32 position
    t2 = (u & MASK_EXP) >> NUM_MAN                 # 6-bit exponent

    bits = (t1 + t3 + ((t2 + MIN_EXP) << 23)).astype(np.uint32)
    bits = np.where((t2 == 0) & (t3 == 0), t1, bits).astype(np.uint32)  # signed zero
    return bits.view(np.float32)


def bf16_to_dlfloat16(x_bf16_bits: np.ndarray) -> np.ndarray:
    """IEEE bfloat16 bit patterns (uint16) -> dlfloat16. bf16 is the top 16 bits of float32,
    so widen to float32 and reuse the float32 path (exact; bf16 mantissa 7 < dlfloat 9)."""
    hi = np.ascontiguousarray(x_bf16_bits, dtype=np.uint16).astype(np.uint32) << 16
    return float32_to_dlfloat16(hi.view(np.float32))


def _selftest() -> None:
    rng = np.random.default_rng(0)
    # values well inside dlfloat's range (exp bias 31 -> ~[2^-31, 2^32]); avoid overflow flush
    x = (rng.standard_normal(200000).astype(np.float32) * 4.0)
    rt = dlfloat16_to_float32(float32_to_dlfloat16(x))

    # round-trip error must be within dlfloat's 9-bit mantissa quantum (rel ~2^-9 ≈ 2e-3)
    nz = np.abs(x) > 1e-6
    rel = np.abs(rt[nz] - x[nz]) / np.abs(x[nz])
    assert rel.max() < 2.0 ** -8, f"round-trip rel err too high: {rel.max():.2e}"

    # exact-representable checks + specials
    for v in (0.0, -0.0, 1.0, -1.0, 2.0, 0.5, -0.25):
        got = dlfloat16_to_float32(float32_to_dlfloat16(np.array([v], np.float32)))[0]
        assert got == np.float32(v), f"{v} -> {got}"
    big = dlfloat16_to_float32(float32_to_dlfloat16(np.array([1e30], np.float32)))[0]
    assert big > 1e9, f"overflow should flush to dlfloat max, got {big}"
    tiny = float32_to_dlfloat16(np.array([1e-30], np.float32))[0]
    assert tiny == 0x0000, f"underflow should flush to +0, got {tiny:#06x}"

    # sign bit preserved on flush-to-zero
    negtiny = float32_to_dlfloat16(np.array([-1e-30], np.float32))[0]
    assert negtiny == 0x8000, f"neg underflow should be -0 (0x8000), got {negtiny:#06x}"

    # bf16 path agrees with the float32 path on bf16-representable values
    xb = (x.view(np.uint32) & 0xFFFF0000).view(np.float32)         # truncate to bf16 grid
    bf_bits = (xb.view(np.uint32) >> 16).astype(np.uint16)
    assert np.array_equal(bf16_to_dlfloat16(bf_bits), float32_to_dlfloat16(xb))

    print(f"dlfloat16 selftest OK  (max round-trip rel err {rel.max():.2e}, "
          f"mean {rel.mean():.2e}; specials + bf16 path + signed-zero pass)")


if __name__ == "__main__":
    _selftest()
