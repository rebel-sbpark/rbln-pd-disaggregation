#!/usr/bin/env python
"""GPU prefill producer: prefill on the GPU, bridge KV to the RBLN on-device layout + dtype, and
publish over the existing pd_nixl transport so an RBLN decode pool consumes it unchanged.
Model-agnostic — the RBLN KV geometry is read from the consumer artifact's rbln_config.json (or
passed explicitly); nothing here assumes a specific model.

Bridge = recode the producer's KV to the RBLN 2-byte on-device type (dlfloat16) + retile to the RBLN
per-layer block layout. RoPE is NOT re-applied (both sides cache post-RoPE K with the model's own
rotary convention — verify per model family); TP head-sharding is handled inside the RBLN _update.

Design: reuse PdNixlKvCore in host-pool mode. The bridge fills core.pool with the recoded KV in RBLN
layout; a no-op copy_op means publish_kv() gathers straight from that pool -> the wire format is
byte-identical to the NPU->NPU producer by construction.

NOTE: the GPU-side path (live NIXL to the NPU, on-GPU dtype convert, batched vLLM prefill) is the part
to validate on hardware; the HF path below is the portable reference for the prefill source.
"""
import os, sys, json, argparse
import numpy as np
import torch

sys.path.insert(0, os.path.dirname(__file__))
from kv_bridge.pack_rbln_kv import pack_layer_block
from pd_nixl_kv_core import PdNixlKvCore   # reused verbatim from the transport kit


def geometry_from_rbln_config(path):
    """Read KV geometry from a consumer decode-pool artifact's rbln_config.json.
    Returns (kv_heads, block_size, head_dim, num_layers)."""
    c = json.load(open(os.path.join(path, "rbln_config.json")))
    metas = c["kvcache_metas"]
    _, kvh, blk, hd = metas[0]["shape"]        # [num_blocks, kv_heads, block_size, head_dim]
    return kvh, blk, hd, len(metas) // 2       # K,V interleaved per layer


def build_producer(engine_id, host, port, kv_dtype, per_numel, num_blocks, block_size, head_dim,
                   n_layers, targets=None):
    names = [f"past_key_values_{i}" for i in range(2 * n_layers)]
    core = PdNixlKvCore(role="producer", engine_id=engine_id, layer_names=names,
                        num_blocks=num_blocks, block_numel=per_numel, dtype=kv_dtype,
                        host=host, port=port, block_size_tok=block_size, head_dim=head_dim,
                        targets=targets)
    core.set_copy_op(lambda pool, blk, size, ln, direction, off=0: None)  # data pre-placed in pool
    return core


def bridge_into_pool(core, past_key_values, L, kvh, blk, hd, n_layers, block=0):
    """Write GPU post-RoPE K/V (HF past_key_values format) into core.pool in RBLN layout/dtype.
    valid-token-only: only the L prompt tokens are packed."""
    for layer in range(n_layers):
        for which, name in ((0, f"past_key_values_{2*layer}"), (1, f"past_key_values_{2*layer+1}")):
            kv = past_key_values[layer][which][0].float().cpu().numpy()   # [kv_heads, L, head_dim]
            packed = pack_layer_block(kv, blk, kvh, hd)                   # uint16, RBLN dtype
            core.pool[name].view(torch.int16)[block] = torch.from_numpy(packed.astype(np.int16))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", required=True, help="HF model id/path to prefill (must match the consumer artifact)")
    ap.add_argument("--consumer-host", required=True)
    ap.add_argument("--consumer-port", type=int, default=9000)
    ap.add_argument("--rbln-config", help="path to the consumer decode-pool artifact (reads KV geometry)")
    ap.add_argument("--kv-heads", type=int); ap.add_argument("--block-size", type=int)
    ap.add_argument("--head-dim", type=int); ap.add_argument("--num-layers", type=int)
    ap.add_argument("--engine-id", default="gpu-p0")
    ap.add_argument("--kv-dtype", default="float16",
                    help="wire dtype; must preserve the RBLN on-device KV bits byte-for-byte")
    ap.add_argument("--prompt", default="The capital of France is")
    args = ap.parse_args()

    if args.rbln_config:
        kvh, blk, hd, n_layers = geometry_from_rbln_config(args.rbln_config)
    elif all(v is not None for v in (args.kv_heads, args.block_size, args.head_dim, args.num_layers)):
        kvh, blk, hd, n_layers = args.kv_heads, args.block_size, args.head_dim, args.num_layers
    else:
        raise SystemExit("provide --rbln-config OR all of --kv-heads/--block-size/--head-dim/--num-layers")
    per_numel = kvh * blk * hd

    from transformers import AutoModelForCausalLM, AutoTokenizer
    dev = "cuda" if torch.cuda.is_available() else "cpu"
    if dev == "cpu":
        print("[warn] no CUDA — running the reference prefill on CPU (production wants a GPU)")
    tok = AutoTokenizer.from_pretrained(args.model)
    model = AutoModelForCausalLM.from_pretrained(
        args.model, dtype=torch.bfloat16 if dev == "cuda" else torch.float32).to(dev).eval()

    core = build_producer(args.engine_id, args.consumer_host, args.consumer_port,
                          getattr(torch, args.kv_dtype), per_numel, num_blocks=64,
                          block_size=blk, head_dim=hd, n_layers=n_layers)
    enc = tok(args.prompt, return_tensors="pt").to(dev)
    L = enc.input_ids.shape[1]
    with torch.no_grad():
        out = model(enc.input_ids, use_cache=True)
    T0 = int(out.logits[0, -1].argmax())
    bridge_into_pool(core, out.past_key_values, L, kvh, blk, hd, n_layers)
    req_id = f"pd-{args.engine_id}-0"
    core.publish_kv(req_id, block_ids=[1], rope_delta=0.0, num_tokens=L)   # valid-token-only
    print(f"[producer] published {req_id}: L={L} T0={T0}({tok.decode([T0])!r}) "
          f"geom(kv_heads={kvh}, block={blk}, head_dim={hd}, layers={n_layers})")


if __name__ == "__main__":
    main()
