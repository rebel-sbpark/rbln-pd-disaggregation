# RUNBOOK — GPU producer bring-up & validation (run on the GPU box)

Validate the GPU producer against a **live** NPU decode pool. Run this **second** — you need the pool
up (from `pd_disagg_consumer_npu/RUNBOOK.md`) and its `CONSUMER_IP` + registered `kv_dtype`. Show the
producer stdout and the consumer's decoder log at each step; prefer an honest "step X failed because…"
over assuming success.

## Prerequisites (STOP if missing)
1. A GPU (`nvidia-smi`).
2. Live NPU pool: `CONSUMER_IP`, a pd_nixl port (e.g. 9000 = d0), the registered `kv_dtype`.
   `nc -vz $CONSUMER_IP 9000` connects.
3. CUDA venv: `python -m venv /workspace/gpuenv && /workspace/gpuenv/bin/pip install -r requirements-gpu.txt`.
4. `"/workspace/gpuenv/bin/python" -c "import sys; sys.path.insert(0,'.'); from kv_bridge.dlfloat import _selftest; _selftest()"`
   → the codec self-test passes.

## Step 1 — live GPU→NPU transfer (do first; everything depends on it)
```bash
MODEL=<hf-id-or-path> CONSUMER_IP=<ip> RBLN_CONFIG=<consumer-artifact-path> bash run_producer_gpu.sh
```
Runs `gpu_prefill_producer.py`: GPU prefill → `bridge_into_pool` → `PdNixlKvCore.publish_kv`
(host-pool mode; wire format byte-identical to the NPU→NPU producer by construction).
- Producer stdout: `[producer] published pd-gpu-p0-0: L=… T0=… geom(...)`.
- Consumer decoder log (`serve_decode_d0.log`): `[EPD 3b] consumer RECEIVED KV advertisement: req=pd-gpu-p0-0 …`
  then, on a decode request, `[EPD] do_load req=pd-gpu-p0-0 … ok=True …` (`pd_nixl_kv.py`) and
  `[EPD] consumer loaded KV req=pd-gpu-p0-0 …` (`optimum_model_runner.py`).
- The producer only *publishes* KV. Full P→D decode orchestration (append T0, trigger decode-skip via
  `kv_transfer_params`) is done by `epd_proxy.py` from the `pd_disagg_producer_npu` kit — copy it and
  point `--p`/`--d` at this producer / the decoder to see the generated token.
- If `RECEIVED KV advertisement` never appears: the pd_nixl port or reverse-path UCX is blocked (NIXL
  READ is consumer→producer) — check `UCX_TLS=cma,tcp,self` on both sides and firewalling. Report it.

## Step 2 — wire-dtype parity (the most likely failure; needs Step 1)
The RBLN KV is a **2-byte on-device type**; the producer must publish so those bits survive
byte-for-byte — a numeric re-type destroys them.
- Symptom: Step 1 shows `do_load … ok=True` (bytes moved) but the decoded token is garbage.
- Fix (one lever): set `--kv-dtype` (via `KV_DTYPE=…`) so the wire buffer element size + bit pattern
  match what the consumer scatters into its pool; reconcile with the consumer's registered `kv_dtype`.
- Confirm: fetch the consumer readback KV and run `kv_bridge.rope_align.verify_matches_rbln(...)`;
  require a high cosine (near 1.0). Only then is the transfer trustworthy.

## Step 3 — throughput hardening (needs Steps 1–2)
- `gpu_prefill_producer.py` ships the reference (HF) prefill. For throughput, swap in vLLM CUDA
  batched prefill and feed its post-RoPE KV export into `bridge_into_pool` (the bridge is unchanged).
- Run the dtype convert on the GPU (torch), overlapping the transfer; a host-side numpy convert is far
  too slow for production.
- Transfer valid tokens only (`num_tokens=L` — already the default), not padded full blocks.

## Step 4 — balance & compare
- Size #GPUs : #decoders so aggregate GPU prefill throughput ≈ aggregate decode consumption. Measure
  the real per-request transfer cost (Step 3) — a transfer-bound pipeline leaves decoders half-empty.
- The bar to beat is the same model served monolithically on the NPUs (measure it): the disaggregated
  pipeline must win on sustained throughput **and** TTFT (it moves the serial NPU prefill onto the GPU).

## Step 5 — larger-TP decoders (only if long contexts need it)
If contexts exceed the TP KV budget, use larger-TP decoders. Before trusting it, verify on a live
artifact that the `_update`/`_fetch` boundary is still the merged all-heads tensor (so the producer
needs no per-rank sharding).

## Fallback
If Steps 1–2 can't be made to work on real GPU↔NPU, use the `pd_disagg_producer_npu` (NPU prefill)
kit — its win is decode-ITL isolation. Residual risk here is transport plumbing / wire dtype; report
precisely which step blocked, with a repro.
