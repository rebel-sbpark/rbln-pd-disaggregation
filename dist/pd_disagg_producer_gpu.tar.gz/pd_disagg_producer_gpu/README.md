# pd_disagg_producer_gpu — GPU prefill producer

Prefill on a GPU, **bridge** the KV to the RBLN on-device layout + dtype, and publish over the
existing pd_nixl transport to an RBLN decode pool (`pd_disagg_consumer_npu`). Model-agnostic — the RBLN
KV geometry is read from the consumer artifact; the model is whatever you point it at.

## Why a bridge (not a raw copy)
RBLN stores KV in a **2-byte on-device float type (dlfloat16)** with an RBLN-specific per-layer block
layout — bit-incompatible with a GPU's IEEE KV. The bridge = **recode to the RBLN dtype + retile to
the RBLN block layout**. RoPE is not re-applied (both sides cache post-RoPE K with the model's own
rotary convention — verify per model family), and TP head-sharding is handled inside the RBLN
`_update` (the producer emits the merged all-heads block).

## Contents
```
gpu_prefill_producer.py   prefill -> bridge_into_pool -> PdNixlKvCore.publish_kv (host-pool mode)
run_producer_gpu.sh       launcher (MODEL, CONSUMER_IP, RBLN_CONFIG or explicit geometry)
requirements-gpu.txt      CUDA deps
kv_bridge/                dlfloat.py (RBLN 2-byte codec), pack_rbln_kv.py (retile), rope_align.py
pd_nixl_transport.py      reused transport (NIXL exact-address READ + ZMQ)
pd_nixl_kv_core.py        reused wire-format orchestration (host-pool mode here)
```

## Setup & run
```bash
python -m venv /workspace/gpuenv && /workspace/gpuenv/bin/pip install -r requirements-gpu.txt
# bring up the consumer pool first; then, pointing at it:
MODEL=<hf-id-or-path> CONSUMER_IP=<npu-decoder-ip> \
  RBLN_CONFIG=<path-to-the-consumer-decodepool-artifact> bash run_producer_gpu.sh
```
`RBLN_CONFIG` lets the producer read the KV geometry (kv_heads / block_size / head_dim / layers) from
the compiled consumer artifact, so it adapts to any model. (Or pass `KV_HEADS/BLOCK_SIZE/HEAD_DIM/NUM_LAYERS`.)

## Validation notes
- **Transport:** `gpu_prefill_producer.py` *publishes* KV; full P→D decode orchestration (append the
  producer's first token, trigger decode-skip) is done by `epd_proxy.py` from the `pd_disagg_producer_npu`
  kit. First proof of a working link is the consumer's `RECEIVED KV advertisement` + `do_load ... ok=True`.
- **Wire dtype:** must preserve the RBLN on-device KV **bits byte-for-byte** — a numeric re-type
  corrupts them. Match `--kv-dtype` to the consumer's registered `kv_dtype`; verify with
  `kv_bridge.rope_align.verify_matches_rbln` on the consumer readback. This is the most likely failure.
- **Throughput:** run the dtype convert on the GPU (torch), overlap it with the transfer, and transfer
  valid tokens only (`num_tokens=L`) rather than padded blocks.

See `RUNBOOK.md` for the step-by-step bring-up/validation checklist.
