#!/usr/bin/env python3
"""epd_proxy — manifest-driven E->P->D orchestration on vllm_rbln (model-agnostic).

Reads logs/topology_manifest.json (written by epd_up.sh). Per request:
  - image requests: round-robin one encoder (E), which publishes embeddings to P's single
    EC bind keyed by mm_hash (existing fan-in; no transport change). Text requests skip E.
  - pick a sticky decode D (round-robin default, or hash(session)).
  - POST P {pd_role:producer, pd_key, pd_dst} (max_tokens=1); then POST the chosen D
    {pd_role:consumer, pd_key} for the real decode. KV is advertised only to that D.

Back-compat: --p/--d override the manifest for ad-hoc 2-instance runs (single decode -> d0).

Usage:
  python epd_proxy.py --prompt "The capital of France is" --max-tokens 16
  python epd_proxy.py --image assets/cats.jpg --max-tokens 24
  python epd_proxy.py --prompt "..." --p http://127.0.0.1:8000 --d http://127.0.0.1:8001
"""
from __future__ import annotations

import argparse
import base64
import hashlib
import json
import sys
import time
import urllib.request
import uuid

DEFAULT_MANIFEST = "/workspace/EPD_Disagg/logs/topology_manifest.json"


def load_manifest(path: str) -> dict:
    with open(path) as f:
        return json.load(f)


def pick_round_robin(state: dict, key: str, n: int) -> int:
    i = state.get(key, 0) % n
    state[key] = i + 1
    return i


def pick_sticky(session: str, n: int) -> int:
    h = int(hashlib.md5(session.encode()).hexdigest(), 16)
    return h % n


def pick_encoder(state: dict, encode: list):
    """Global round-robin over all encoders (fan-out: any encoder feeds any prefill).

    With metadata fan-out the encoder advertises embeddings to every prefill, so the
    encoder choice is decoupled from the chosen prefill. Returns the chosen encoder
    dict, or None when there are no encoders (text-only path)."""
    if not encode:
        return None
    return encode[pick_round_robin(state, "encode", len(encode))]


def resolve_decode_index(decode: list, sel: str) -> int:
    # sel may be a decode id ("d1") or an integer index ("1"); returns the index.
    for i, d in enumerate(decode):
        if d["id"] == sel:
            return i
    try:
        idx = int(sel)
    except ValueError:
        raise SystemExit(f"--decode {sel!r}: no such decode id and not an int index")
    if not (0 <= idx < len(decode)):
        raise SystemExit(f"--decode index {idx} out of range (0..{len(decode)-1})")
    return idx


def _post(url: str, path: str, payload: dict, timeout: float = 180.0) -> dict:
    data = json.dumps(payload).encode()
    req = urllib.request.Request(url.rstrip("/") + path, data=data,
                                 headers={"Content-Type": "application/json"}, method="POST")
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode())


def _model_id(url: str) -> str:
    req = urllib.request.Request(url.rstrip("/") + "/v1/models")
    with urllib.request.urlopen(req, timeout=30) as r:
        return json.loads(r.read().decode())["data"][0]["id"]


def _img_msgs(data_uri: str, prompt: str) -> list:
    return [{"role": "user", "content": [
        {"type": "image_url", "image_url": {"url": data_uri}},
        {"type": "text", "text": prompt}]}]


def _chat_content(out: dict) -> str:
    return out.get("choices", [{}])[0].get("message", {}).get("content", "")


def _completion_text(out: dict) -> str:
    return out.get("choices", [{}])[0].get("text", "")


def run_one(manifest: dict, *, prompt=None, image=None, image_prompt="Describe this image in one sentence.",
            max_tokens=16, temperature=0.0, session=None, state=None, model=None,
            decode_index: int | None = None, max_tokens_p: int = 1) -> dict:
    state = state if state is not None else {}
    decode = manifest["decode"]
    pf = manifest["prefill"]
    pf = pf if isinstance(pf, list) else [pf]
    pi = pick_round_robin(state, "prefill", len(pf))
    p_url = pf[pi]["url"]
    p_id = pf[pi].get("id", f"p{pi}")
    model = model or _model_id(p_url)
    pd_key = "pd-" + uuid.uuid4().hex[:16]

    # decode pick: explicit override > sticky (session) > round-robin
    if decode_index is not None:
        di = decode_index
    elif session:
        di = pick_sticky(session, len(decode))
    else:
        di = pick_round_robin(state, "decode", len(decode))
    d = decode[di]
    pd_dst = d["id"]

    is_image = image is not None
    if is_image:
        with open(image, "rb") as _f:
            b64 = base64.b64encode(_f.read()).decode()
        msgs = _img_msgs(f"data:image/jpeg;base64,{b64}", image_prompt)
        # Phase 0: encode on ANY encoder (global round-robin). With metadata fan-out the
        # encoder advertises embeddings to every prefill, so encoder choice is decoupled
        # from the chosen P — the routed P is the only one that pulls the tensor.
        enc = manifest.get("encode") or []
        chosen_enc = pick_encoder(state, enc)
        if chosen_enc is not None:
            _post(chosen_enc["url"], "/v1/chat/completions",
                  {"model": model, "messages": msgs, "max_tokens": max_tokens_p, "temperature": 0.0})
        # Phase 1: P prefill+publish KV to chosen D
        _post(p_url, "/v1/chat/completions",
              {"model": model, "messages": msgs, "max_tokens": max_tokens_p, "temperature": temperature,
               "kv_transfer_params": {"pd_role": "producer", "pd_key": pd_key, "pd_dst": pd_dst}})
        # Phase 2: chosen D decode
        d_out = _post(d["url"], "/v1/chat/completions",
                      {"model": model, "messages": msgs, "max_tokens": max_tokens,
                       "temperature": temperature,
                       "kv_transfer_params": {"pd_role": "consumer", "pd_key": pd_key}})
        text = _chat_content(d_out)
    else:
        _post(p_url, "/v1/completions",
              {"model": model, "prompt": prompt, "max_tokens": max_tokens_p, "temperature": temperature,
               "kv_transfer_params": {"pd_role": "producer", "pd_key": pd_key, "pd_dst": pd_dst}})
        d_out = _post(d["url"], "/v1/completions",
                      {"model": model, "prompt": prompt, "max_tokens": max_tokens,
                       "temperature": temperature,
                       "kv_transfer_params": {"pd_role": "consumer", "pd_key": pd_key}})
        text = _completion_text(d_out)
    return {"pd_key": pd_key, "pd_dst": pd_dst, "d_url": d["url"], "text": text}


def _manifest_from_override(p_url: str, d_url: str) -> dict:
    return {"encode": [], "prefill": {"id": "p0", "url": p_url},
            "decode": [{"id": "d0", "url": d_url}]}


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--manifest", default=DEFAULT_MANIFEST)
    ap.add_argument("--p", help="override prefill URL (ad-hoc, single decode)")
    ap.add_argument("--d", help="override decode URL (ad-hoc, single decode)")
    ap.add_argument("--prompt", default="The capital of France is")
    ap.add_argument("--prompt-file")
    ap.add_argument("--image")
    ap.add_argument("--image-prompt", default="Describe this image in one sentence.")
    ap.add_argument("--max-tokens", type=int, default=16)
    ap.add_argument("--temperature", type=float, default=0.0)
    ap.add_argument("--session")
    ap.add_argument("--model", default=None)
    ap.add_argument("--decode", default=None, help="force a specific decode instance by id (e.g. 'd1') or index (e.g. '1')")
    args = ap.parse_args()

    if args.p and args.d:
        manifest = _manifest_from_override(args.p, args.d)
    else:
        manifest = load_manifest(args.manifest)

    prompt = args.prompt
    if args.prompt_file:
        with open(args.prompt_file) as _pf:
            prompt = _pf.read()

    decode_index = None
    if args.decode is not None:
        decode_index = resolve_decode_index(manifest["decode"], args.decode)

    t0 = time.perf_counter()
    out = run_one(manifest, prompt=(None if args.image else prompt), image=args.image,
                  image_prompt=args.image_prompt, max_tokens=args.max_tokens,
                  temperature=args.temperature, session=args.session, model=args.model,
                  decode_index=decode_index)
    dt = (time.perf_counter() - t0) * 1000
    print(f"[epd] key={out['pd_key']} -> {out['pd_dst']} ({out['d_url']}) {dt:.0f} ms")
    print(f"[epd] OUTPUT: {out['text']!r}")
    return 0 if out["text"] else 1


if __name__ == "__main__":
    sys.exit(main())
