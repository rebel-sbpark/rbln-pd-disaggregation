#!/usr/bin/env bash
# NPU prefill producer — start after the decode consumer is up. Model-agnostic: set MODEL_DIR.
#   CONSUMER_IP=<decoder-ip> MODEL_DIR=<compiled-artifact> RBLN_DEVICES=0,1 bash run_producer.sh
set -euo pipefail
VENV="${VENV:-/workspace/benchmark/.venv}"
MODEL_DIR="${MODEL_DIR:?set MODEL_DIR to a compiled RBLN artifact}"
CONSUMER_IP="${CONSUMER_IP:?set CONSUMER_IP (the decode box IP)}"
HTTP_PORT="${HTTP_PORT:-8000}"     # prefill HTTP port (the proxy attaches here)
PD_PORT="${PD_PORT:-9000}"         # consumer's pd_nixl recv port (must match the consumer)
RBLN_DEVICES="${RBLN_DEVICES:-0,1}"
MAX_NUM_SEQS="${MAX_NUM_SEQS:-4}"
LOG="${LOG:-serve_producer.log}"
# VLM models only: pass image preprocessing via MM_PROCESSOR_KWARGS (JSON); empty for text models.
MM_KW="${MM_PROCESSOR_KWARGS:-}"

KVT='{"kv_connector":"PdNixlKvConnector","kv_role":"kv_producer","kv_buffer_device":"cpu","kv_connector_extra_config":{"pd_host":"'"$CONSUMER_IP"'","pd_port":'"$PD_PORT"',"pd_load_advert_timeout_s":0,"pd_load_xfer_timeout_s":10.0}}'

echo "[producer] model=$MODEL_DIR http=:$HTTP_PORT advertise->$CONSUMER_IP:$PD_PORT devices=$RBLN_DEVICES log=$LOG"
UCX_TLS="${UCX_TLS:-cma,tcp,self}" RBLN_DEVICES="$RBLN_DEVICES" VLLM_USE_V1=1 RBLN_NUM_THREADS="${RBLN_NUM_THREADS:-8}" \
"$VENV/bin/vllm" serve "$MODEL_DIR" \
  --trust-remote-code \
  --host 0.0.0.0 --port "$HTTP_PORT" \
  --max-num-seqs "$MAX_NUM_SEQS" \
  ${MM_KW:+--mm-processor-kwargs "$MM_KW"} \
  --kv-transfer-config "$KVT" \
  > "$LOG" 2>&1 &
echo "[producer] pid=$!  ->  when ready, run epd_proxy.py to orchestrate P->D (see README)"
