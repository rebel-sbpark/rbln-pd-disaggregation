# pd_disagg_producer_npu — NPU prefill producer

The **prefill** half of an all-RBLN prefill/decode pipeline: this box prefills on RBLN NPUs and its KV
is moved over pd_nixl (NIXL/UCX + ZMQ) to the decode pool (`pd_disagg_consumer_npu`). Model-agnostic —
set `MODEL_DIR` to any compiled RBLN artifact.

Because producer and consumer are identical RBLN devices, KV moves as a **raw byte copy**
(device→host `_fetch_kv_cache` → NIXL READ → host→device `_update_kv_cache`) — no dtype/layout bridge
is needed (unlike the GPU producer, which must recode + retile).

## Contents
```
install.sh          # apply the vllm_rbln overlay (pd_nixl connector + decode-skip runner)
run_producer.sh     # start the NPU prefill instance (kv_producer)
epd_proxy.py        # P->D orchestrator (append the producer's first token, drive decode-skip)
vllm_rbln_overlay/  # the vllm_rbln overlay (kv_producer path)
```
`epd_proxy.py` is the P→D orchestrator that the GPU-producer kit refers to — it lives here.

## Run — decode (consumer) FIRST, then this producer
1. Bring up the decode pool from `pd_disagg_consumer_npu` (it binds the pd_nixl sockets).
2. On this box, point at the consumer and start prefill:
   ```bash
   VENV=/workspace/benchmark/.venv bash install.sh          # once
   CONSUMER_IP=<decoder-ip> MODEL_DIR=<compiled-artifact> RBLN_DEVICES=0,1 bash run_producer.sh
   ```
   For VLM models, pass image preprocessing via `MM_PROCESSOR_KWARGS='{...}'`.
3. Orchestrate P→D:
   ```bash
   /workspace/benchmark/.venv/bin/python epd_proxy.py \
     --p http://127.0.0.1:8000 --d http://<decoder-ip>:8001 \
     --prompt "..." --max-tokens 16
   ```
   Expect a coherent completion and matching `pd_key` in both logs (`[EPD] do_save published … key=pd-…`
   here, `[EPD] do_load … ok=True` on the decoder).

## NPU-prefill vs GPU-prefill
- **producer_npu (this):** all-RBLN; NPU prefill is serial (one request/step), so its win is
  **decode-ITL isolation** under prefill interference rather than raw throughput.
- **producer_gpu:** parallel GPU prefill (needs the dlfloat16 + layout KV bridge). See that kit's RUNBOOK.
