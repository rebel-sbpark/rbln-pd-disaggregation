# RUNBOOK — NPU decode pool bring-up (run on the RBLN box)

Bring up the decode pool. Do this **first** — the producer needs this box's IP and the decoders'
pd_nixl ports. Check each step's output before proceeding.

## Step 0 — preconditions (STOP if any fail)
1. RBLN cards present: `ls /dev/rbln*` — enough for `N_DECODERS × TP`.
2. `"$VENV/bin/python" -c "import rebel, optimum.rbln, vllm_rbln"` (default `VENV=/workspace/benchmark/.venv`).
3. Apply the overlay (idempotent): `VENV=/workspace/benchmark/.venv bash install.sh` — must end with
   `pd_nixl_kv_core import OK`.

## Step 1 — compile the decode artifact for your model
Set the knobs for your model + card count (see README "Choosing the knobs"):
```bash
MODEL_ID=<hf-id-or-path> TP=<t> DECODE_BATCHES=<e.g. 32,16,8,4> \
  KVCACHE_NUM_BLOCKS=<explicit; below the auto-max> PHASES_DECODE_ONLY=1 \
  RBLN_DEVICES=0,1 "$VENV/bin/python" compile_decode_pool.py
```
To find a safe `KVCACHE_NUM_BLOCKS`: compile once with `0` (auto), read the printed
`kvcache_num_blocks`, then recompile at ~80–85% of it for DRAM headroom. Expect the artifact to
contain `prefill.rbln` + one `decoder_batch_<n>.rbln` per DECODE_BATCHES value (the prefill graph
ships even with `phases=["decode"]` — expected).

## Step 2 — launch the pool
```bash
MODEL_DIR=<the compiled artifact> N_DECODERS=<n> TP=<t> bash run_consumer_npu.sh
```
It sets the RBLN envs, refuses an auto-edge artifact (headroom guard), pins CPUs, and launches
`d0..d(N-1)` on consecutive card groups, HTTP `8001..`, pd_nixl recv `9000..`. Health-gate:
```bash
for p in $(seq 8001 $((8000+N_DECODERS))); do curl -s -o /dev/null -w "$p:%{http_code}\n" localhost:$p/health; done
```
All must reach `200`. On failure, inspect `serve_decode_d<i>.log`.

## Step 3 — hand two values to the producer
1. **CONSUMER_IP** — `hostname -I | awk '{print $1}'` (pd_nixl `9000..`, HTTP `8001..`).
2. **Registered kv_dtype** — `grep -h "register_runtime done" serve_decode_d0.log` → `... dtype=<X>`.
   The producer's KV wire dtype must preserve the on-device KV **bits byte-for-byte** (RBLN KV is a
   2-byte type; a numeric re-type corrupts it). This is the most likely producer-side failure — pass
   the value along.

## Success
All decoders `200`; the headroom guard printed `nb=...`; `CONSUMER_IP` and the registered `kv_dtype`
reported. Leave the pool running for the producer.
