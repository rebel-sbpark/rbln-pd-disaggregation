"""pd_nixl transport core — per-request-keyed, exact-address host-buffer KV transfer.

The NPU-free, vLLM-free heart of the Option-B connector (pd_nixl_kv.py). Combines:
  - NIXL exact-address DRAM transfer (validated in tests/test_nixl_loopback.py), and
  - a per-request ZMQ side channel (validated in tests/test_c_per_request_key.py).

Producer.publish(request_id, host_buffer): register the buffer with NIXL, push its
(engine_id, request_id, base_addr, nbytes, agent_metadata) to the consumer keyed by request_id.
Consumer.pull(request_id, dst_buffer): wait for that request's metadata, NIXL-READ the exact
bytes into dst_buffer. Keying by request_id is what prevents the FIFO desync / N-lag.

This module is deliberately independent of NPU/vLLM so it can be unit-tested cross-process.
The vLLM connector (pd_nixl_kv.py) will own buffer lifecycle + d2h/h2d and call these.
"""
from __future__ import annotations

import os
import queue
import threading
import time

import msgspec
import torch
import zmq

# Import the epd_trace sink. This module runs BOTH as src/pd_nixl_transport.py
# (epd_trace adjacent) AND as the installed vllm_rbln copy (epd_trace lives at the
# absolute EPD_Disagg/src path, NOT next to this file). Try both locations so the
# same file works in either deployment.
try:
    import sys as _sys, os as _os
    for _p in (_os.path.dirname(_os.path.abspath(__file__)), "/workspace/EPD_Disagg/src"):
        if _p not in _sys.path:
            _sys.path.insert(0, _p)
    import epd_trace as _epd_trace_mod
    # Re-use already-imported src.epd_trace if present (avoids aliasing in tests)
    _epd_trace_mod = _sys.modules.get("src.epd_trace", _epd_trace_mod)
    def _trace_emit(name, **kw): return _epd_trace_mod.emit(name, **kw)
    def _trace_on(): return _epd_trace_mod.enabled()
    def _trace_now(): return _epd_trace_mod.now_mono()
except Exception:
    def _trace_emit(name, **kw): pass  # type: ignore[misc]
    def _trace_on(): return False  # type: ignore[misc]
    def _trace_now(): return 0.0  # type: ignore[misc]

# cma,tcp,self: CMA (fast intra-node RMA for private DRAM, ~12 GB/s) + tcp (control + fallback) +
# self. Old `^cma` excluded cma -> UCX used TCP/eth0 (~1.6 GB/s). Fallback to tcp is automatic if
# CMA can't establish (e.g. cross-host), so this is a strict superset. Verified byte-exact on HW.
os.environ.setdefault("UCX_TLS", "cma,tcp,self")
_BACKENDS = ["UCX"]


def _pd_diag(kind: str, msg: str) -> None:
    """Append+flush a side-channel diagnostic line (bypasses logger/thread issues)."""
    try:
        with open("/workspace/EPD_Disagg/logs/pd_sidechannel.txt", "a") as f:
            f.write(f"[{kind}] {msg}\n")
            f.flush()
    except Exception:
        pass


class PdKvMeta(msgspec.Struct):
    engine_id: str
    request_id: str
    base_addr: int
    nbytes: int
    agent_metadata: bytes
    rope_delta: float = 0.0
    num_tokens: int = 0  # valid token count in the compact buffer (0 = legacy full-block)


def _nixl_agent(name: str):
    from nixl._api import nixl_agent
    return nixl_agent(name, None)


class PdNixlProducer:
    """Prefill-side endpoint: registers host buffers and advertises them per request."""

    def __init__(self, engine_id: str, host: str | None = None,
                 port: int | None = None, targets: dict | None = None):
        self.engine_id = engine_id
        self._agent = _nixl_agent(f"pd-prod-{engine_id}")
        self._enc = msgspec.msgpack.Encoder()
        self._ctx = zmq.Context.instance()
        if targets is None:
            assert host is not None and port is not None, \
                "PdNixlProducer needs targets={id:(host,port)} or host+port"
            targets = {"d0": (host, int(port))}
        assert targets, "PdNixlProducer needs at least one target"
        # one PUSH socket per decode instance; connect each. dst selects at publish().
        self._socks: dict[str, "zmq.Socket"] = {}
        for tid, (h, p) in targets.items():
            s = self._ctx.socket(zmq.PUSH)
            s.setsockopt(zmq.LINGER, 2000)
            addr = f"tcp://{h}:{int(p)}"
            s.connect(addr)
            self._socks[tid] = s
            _pd_diag("producer-init", f"PUSH connect -> {addr} engine={engine_id} dst={tid}")
        self._default = next(iter(self._socks))
        self._registered: dict[str, object] = {}  # request_id -> reg descs (keep alive)

    def publish(self, request_id: str, host_buffer, rope_delta: float = 0.0,
                dst: str | None = None, num_tokens: int = 0) -> None:
        nbytes = host_buffer.numel() * host_buffer.element_size()
        descs = self._agent.get_reg_descs([(host_buffer.data_ptr(), nbytes, 0, "")], "DRAM")
        self._agent.register_memory(descs, backends=_BACKENDS)
        self._registered[request_id] = (descs, host_buffer)  # retain until released
        meta = PdKvMeta(
            engine_id=self.engine_id,
            request_id=request_id,
            base_addr=host_buffer.data_ptr(),
            nbytes=nbytes,
            agent_metadata=self._agent.get_agent_metadata(),
            rope_delta=float(rope_delta),
            num_tokens=int(num_tokens),
        )
        sock = self._socks.get(dst) if dst is not None else None
        if sock is None:
            sock = self._socks[self._default]
        sock_key = dst if (dst is not None and dst in self._socks) else self._default
        sock.send(self._enc.encode(meta))
        _trace_emit("nixl_push", track=f"P{self.engine_id}", ph="i",
                    args={"request_id": request_id, "nbytes": nbytes,
                          "rope_delta": float(rope_delta), "dst": sock_key,
                          "num_tokens": int(num_tokens)})
        _pd_diag("send", f"req={request_id} nbytes={nbytes} rope_delta={rope_delta} "
                         f"dst={sock_key}")

    def release(self, request_id: str) -> None:
        self._registered.pop(request_id, None)

    def close(self) -> None:
        for s in self._socks.values():
            s.close(0)


class PdNixlConsumer:
    """Decode-side endpoint: receives per-request advertisements and pulls KV by address."""

    def __init__(self, engine_id: str, bind_host: str, bind_port: int, async_load: bool = False):
        self.engine_id = engine_id
        self._agent = _nixl_agent(f"pd-cons-{engine_id}")
        self._dec = msgspec.msgpack.Decoder(PdKvMeta)
        self._ctx = zmq.Context.instance()
        self._pull = self._ctx.socket(zmq.PULL)
        self._bind_addr = f"tcp://{bind_host}:{bind_port}"
        self._pull.bind(self._bind_addr)
        _pd_diag("consumer-init", f"PULL bind {self._bind_addr} engine={engine_id}")
        self._meta_by_req: dict[str, PdKvMeta] = {}
        self._remote_names: dict[str, str] = {}  # engine_id -> nixl remote agent name
        self._events: dict[str, threading.Event] = {}
        self._lock = threading.Lock()
        self._stop = threading.Event()
        # PD_ASYNC_LOAD: prefetch the NIXL READ (host->host) in the _recv_loop the moment the
        # producer advertises, so the engine-step `pull` finds the bytes already in a host
        # buffer and only does a fast memcpy — the ~16ms READ no longer stalls the running
        # decode batch. Default OFF (sync path unchanged). The READ touches no device memory,
        # so it is safe off the engine thread; all NIXL-agent ops are serialized by
        # `_agent_lock` so the prefetch thread and the engine-thread fallback never race.
        self._prefetch_on = bool(async_load) or (
            os.getenv("PD_ASYNC_LOAD", "0") not in ("0", "", "false", "False"))
        self._prefetched: dict[str, tuple] = {}  # req_id -> (host_buf_uint8, ok)
        self._prefetch_done: dict[str, threading.Event] = {}  # req_id -> READ-complete signal
        self._agent_lock = threading.Lock()
        self._rx = threading.Thread(target=self._recv_loop, daemon=True, name="pd-nixl-rx")
        self._rx.start()

    def _event_for(self, request_id: str) -> threading.Event:
        with self._lock:
            return self._events.setdefault(request_id, threading.Event())

    def _recv_loop(self) -> None:
        poller = zmq.Poller()
        poller.register(self._pull, zmq.POLLIN)
        _pd_diag("consumer-rx", f"receiver thread started on {self._bind_addr}")
        while not self._stop.is_set():
            if not dict(poller.poll(200)):
                continue
            try:
                raw = self._pull.recv(zmq.NOBLOCK)
            except zmq.Again:
                continue
            _pd_diag("consumer-rx", f"got {len(raw)} bytes on wire")
            try:
                meta = self._dec.decode(raw)
            except Exception as e:
                _pd_diag("consumer-rx", f"DECODE ERROR {type(e).__name__}: {e}")
                continue
            with self._lock:
                # Re-add on every metadata: each publish registers a new buffer, so the
                # agent metadata must be refreshed for NIXL to know that buffer's memory
                # (caching once leaves later requests' addresses NOT_FOUND). NIXL keys by
                # agent name and updates the known memory descriptors on re-add.
                self._remote_names[meta.engine_id] = self._agent.add_remote_agent(
                    meta.agent_metadata
                )
                self._meta_by_req[meta.request_id] = meta
                _trace_emit("nixl_rx", track=f"D{self.engine_id}", ph="i",
                            args={"request_id": meta.request_id,
                                  "engine_id": meta.engine_id, "nbytes": meta.nbytes})
                if self._prefetch_on:
                    # Create the done-signal BEFORE releasing the lock / setting the advert
                    # event, so a pull that wakes immediately finds it and waits (instead of
                    # racing a duplicate READ).
                    self._prefetch_done[meta.request_id] = threading.Event()
                self._events.setdefault(meta.request_id, threading.Event()).set()
            # PD_ASYNC_LOAD: start the NIXL READ now (host->host), in THIS background thread,
            # so the engine-step pull is a memcpy. Serialized here (one READ at a time) + via
            # _agent_lock vs the engine-thread fallback. Failure just leaves no prefetch entry
            # -> pull falls back to a synchronous READ. dst is a raw uint8 byte buffer; the
            # consumer core reinterprets it via dst_buffer.view(uint8).copy_ on the hit path.
            if self._prefetch_on:
                self._prefetch_read(meta, self._prefetch_done.get(meta.request_id))
            try:
                import logging as _lg
                _lg.getLogger("vllm_rbln").info(
                    "[EPD 3b] consumer RECEIVED KV advertisement: req=%s engine=%s nbytes=%s",
                    meta.request_id, meta.engine_id, meta.nbytes,
                )
            except Exception:
                pass

    def _prefetch_read(self, meta, done_ev) -> None:
        """Background READ of meta's KV into a fresh host byte buffer; stash for pull() to hand
        off. Runs in the _recv_loop thread. Never raises into the loop. `done_ev` is signalled
        when the READ has finished (success or not) so a waiting pull() unblocks."""
        try:
            with self._lock:
                remote_name = self._remote_names.get(meta.engine_id)
            if remote_name is None:
                return
            buf = torch.empty(meta.nbytes, dtype=torch.uint8)
            _t = _trace_now() if _trace_on() else None
            ok = self._do_read(meta.request_id, meta, remote_name, buf, timeout=10.0)
            if _t is not None:
                _trace_emit("kv_prefetch", track=f"D{self.engine_id}", ph="X", ts=_t,
                            dur=_trace_now() - _t,
                            args={"request_id": meta.request_id, "nbytes": meta.nbytes, "ok": ok})
            with self._lock:
                self._prefetched[meta.request_id] = (buf, ok)
        except Exception as e:  # never kill the recv loop
            _pd_diag("prefetch", f"req={getattr(meta,'request_id','?')} FAILED {type(e).__name__}: {e}")
        finally:
            if done_ev is not None:
                done_ev.set()

    def pull(self, request_id: str, dst_buffer, timeout: float = 10.0,
             advert_timeout: float | None = None) -> bool:
        """NIXL-READ request_id's KV into dst_buffer.

        Two waits, decoupled so a genuine miss never blocks the engine step:
          - advert_timeout: how long to wait for the producer's ZMQ advertisement of this
            pd_key. 0 = FULLY NON-BLOCKING (the background _recv_loop already set the event
            on the happy path, so a still-unset event means the key was never published →
            return False immediately). Defaults to `timeout` when None (legacy behavior).
          - timeout: how long to wait for the actual NIXL READ to complete once advertised
            (the legitimate transfer; must be > 0).
        """
        aw = timeout if advert_timeout is None else advert_timeout
        if not self._event_for(request_id).wait(aw):
            return False
        # PD_ASYNC_LOAD fast path: the _recv_loop is (or is about to be) READing this request's
        # KV into a host buffer in the background. Wait for that in-flight READ (NOT a duplicate
        # sync READ — the two would serialize on _agent_lock anyway), then hand it over with a
        # byte memcpy (~ms), skipping the on-step NIXL READ.
        if self._prefetch_on:
            done = self._prefetch_done.get(request_id)
            if done is not None:
                done.wait(timeout)
            self._prefetch_done.pop(request_id, None)
            pre = self._prefetched.pop(request_id, None)
            if pre is not None:
                buf, ok = pre
                if ok and buf.numel() == dst_buffer.numel() * dst_buffer.element_size():
                    _t_hit = _trace_now() if _trace_on() else None
                    dst_buffer.view(torch.uint8).copy_(buf)
                    if _t_hit is not None:
                        _trace_emit("nixl_pull", track=f"D{self.engine_id}", ph="X", ts=_t_hit,
                                    dur=_trace_now() - _t_hit,
                                    args={"request_id": request_id, "ok": True, "prefetched": True})
                    return True
            # prefetch failed/size-mismatch/absent -> fall through to a synchronous READ.
        with self._lock:
            meta = self._meta_by_req[request_id]
            remote_name = self._remote_names[meta.engine_id]
        nbytes = dst_buffer.numel() * dst_buffer.element_size()
        assert nbytes == meta.nbytes, f"size mismatch {nbytes} != {meta.nbytes}"
        return self._do_read(request_id, meta, remote_name, dst_buffer, timeout)

    def _do_read(self, request_id, meta, remote_name, dst_buffer, timeout: float) -> bool:
        """The actual NIXL READ of meta's KV into dst_buffer. Called on the engine thread (sync
        pull) OR the _recv_loop thread (prefetch); all agent ops are serialized by _agent_lock so
        the two never race on the NIXL agent."""
        nbytes = dst_buffer.numel() * dst_buffer.element_size()
        with self._agent_lock:
            _t_reg = _trace_now() if _trace_on() else None
            local = self._agent.get_reg_descs([(dst_buffer.data_ptr(), nbytes, 0, "")], "DRAM")
            self._agent.register_memory(local, backends=_BACKENDS)
            lx = self._agent.prep_xfer_dlist("NIXL_INIT_AGENT", [(dst_buffer.data_ptr(), nbytes, 0)], "DRAM")
            rx = self._agent.prep_xfer_dlist(remote_name, [(meta.base_addr, meta.nbytes, 0)], "DRAM")
            h = self._agent.make_prepped_xfer("READ", lx, [0], rx, [0], notif_msg=b"")
            if _t_reg is not None:
                _trace_emit("nixl_reg", track=f"D{self.engine_id}", ph="X", ts=_t_reg,
                            dur=_trace_now() - _t_reg, args={"request_id": request_id, "nbytes": nbytes})
            _t_pull = _trace_now() if _trace_on() else None
            self._agent.transfer(h)
            deadline = time.time() + timeout
            # Adaptive backoff, not a fixed 20ms quantum. A small loopback transfer (~ms) was
            # previously rounded up to the 20ms sleep floor (and a transfer just over 20ms cost
            # 40ms — two quanta). Start sub-ms and grow geometrically to a 5ms cap: fast transfers
            # are detected within <1ms; long transfers (e.g. a 1.2GB large-prompt READ) poll at the
            # 5ms cap so the loop stays cheap on CPU (decode is host-CPU-bound; don't busy-spin).
            sleep_s = 0.0002
            while time.time() < deadline:
                st = self._agent.check_xfer_state(h)
                if st in ("DONE", "ERR"):
                    if _t_pull is not None:
                        _trace_emit("nixl_pull", track=f"D{self.engine_id}", ph="X",
                                    ts=_t_pull, dur=_trace_now() - _t_pull,
                                    args={"request_id": request_id, "ok": st == "DONE"})
                    return st == "DONE"
                time.sleep(sleep_s)
                if sleep_s < 0.005:
                    sleep_s = min(0.005, sleep_s * 1.5)
            return False

    def get_rope_delta(self, request_id: str) -> float:
        """rope_delta advertised alongside the KV (0.0 for text-only). Call after pull()."""
        with self._lock:
            meta = self._meta_by_req.get(request_id)
            return float(meta.rope_delta) if meta is not None else 0.0

    def get_num_tokens(self, request_id: str) -> int:
        """valid token count advertised with the compact KV buffer (0 = legacy full-block)."""
        with self._lock:
            meta = self._meta_by_req.get(request_id)
            return int(meta.num_tokens) if meta is not None else 0

    def close(self) -> None:
        self._stop.set()
        if self._rx.is_alive():
            self._rx.join(timeout=1.0)
        self._pull.close(0)
