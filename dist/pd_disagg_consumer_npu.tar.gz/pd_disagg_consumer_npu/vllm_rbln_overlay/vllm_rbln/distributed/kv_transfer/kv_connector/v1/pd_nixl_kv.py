# Copyright 2025 Rebellions Inc. All rights reserved.
# Licensed under the Apache License, Version 2.0 (the "License").
"""PdNixlKvConnector — Option-B P/D KV connector for the vllm_rbln OPTIMUM path.

Why bespoke (not the stock RblnNixlConnector): the base NixlConnectorWorker needs vLLM
attention-backends + hybrid-allocator KV layout (register_kv_caches at nixl_connector.py:1494)
that the optimum single-compiled-graph path never constructs. See
EPD_Disagg/results/zeros-investigation.md. This connector transfers host buffers by EXACT
NIXL address with a per-request ZMQ key (validated NPU-free in EPD_Disagg/tests/), bypassing
register_kv_caches entirely.

Execution model: the optimum runner runs one opaque self.model(model_input) forward with NO
per-layer attention hooks, so vLLM's layer-by-layer connector API (start_load_kv /
wait_for_layer_load / save_kv_layer) is never called here — those are no-op stubs. Transfer is
driven EXPLICITLY by the optimum runner (like the EC connector) via publish_kv / load_kv, using
the framework-free PdNixlKvCore (gather/scatter + d2h/h2d via the rebel runtime).
"""
from __future__ import annotations

import json
import os
from typing import TYPE_CHECKING, Any

import torch
from vllm.config import VllmConfig
from vllm.distributed.kv_transfer.kv_connector.v1.base import (
    KVConnectorBase_V1,
    KVConnectorMetadata,
    KVConnectorRole,
)

from vllm_rbln.logger import init_logger

from .pd_nixl_kv_core import PdNixlKvCore

if TYPE_CHECKING:
    from vllm.forward_context import ForwardContext
    from vllm.v1.core.kv_cache_manager import KVCacheBlocks
    from vllm.v1.core.sched.output import SchedulerOutput
    from vllm.v1.kv_cache_interface import KVCacheConfig
    from vllm.v1.request import Request

logger = init_logger(__name__)

_DEFAULT_HOST = "127.0.0.1"
_DEFAULT_PORT = 16200


def parse_pd_consumers(get_extra, default_host: str, default_port: int) -> dict:
    """Producer routing targets: {dst_id: (host, port)}.

    Reads ``pd_consumers`` from kv_connector_extra_config — a list of
    {"id","host","port"} (or a JSON string thereof). Absent ⇒ single consumer
    "d0" from pd_host/pd_port (back-compat with the 2-instance recipe).
    ``get_extra(key, default)`` mirrors VllmConfig.kv_transfer_config.get_from_extra_config.
    """
    raw = get_extra("pd_consumers", None)
    if not raw:
        return {"d0": (default_host, int(default_port))}
    items = json.loads(raw) if isinstance(raw, str) else raw
    out = {}
    for it in items:
        out[it["id"]] = (it.get("host", default_host), int(it["port"]))
    return out


class PdNixlKvConnectorMetadata(KVConnectorMetadata):
    """Per-step metadata built by the scheduler, bound + consumed by the worker.

    reqs_to_save: producer  req_id -> (pd_key, block_ids, pd_dst)  (publish after prefill)
    reqs_to_load: consumer  req_id -> (pd_key, consumer_block_ids)  (NIXL READ before decode)
    """

    def __init__(self) -> None:
        self.reqs_to_load: dict[str, tuple[str, list[int]]] = {}
        self.reqs_to_save: dict[str, tuple[str, list[int], "str | None"]] = {}


class PdNixlKvConnector(KVConnectorBase_V1):
    def __init__(
        self,
        vllm_config: VllmConfig,
        role: KVConnectorRole,
        kv_cache_config: "KVCacheConfig | None" = None,
    ) -> None:
        super().__init__(vllm_config, role, kv_cache_config)
        cfg = vllm_config.kv_transfer_config
        assert cfg is not None
        self._engine_id = cfg.engine_id
        self._kv_role = cfg.kv_role  # "kv_producer" | "kv_consumer" | "kv_both"
        self._host = cfg.get_from_extra_config("pd_host", _DEFAULT_HOST)
        self._port = int(cfg.get_from_extra_config("pd_port", _DEFAULT_PORT))
        # Producer routing targets (one PUSH socket per decode instance). Absent ⇒ {d0}.
        self._targets = parse_pd_consumers(cfg.get_from_extra_config, self._host, self._port)
        # [EPD] Consumer KV-load waits, decoupled (see PdNixlTransport.pull):
        #  - advert: wait for the producer's pd_key advertisement. 0 = FULLY NON-BLOCKING
        #    (a genuine miss / bad key returns immediately instead of stalling the engine
        #    step ~10s). Happy path is unaffected — the advertisement is already received by
        #    the time the consumer decodes (producer publishes before the proxy calls D).
        #  - xfer: wait for the actual NIXL READ to complete once advertised (must be > 0).
        self._load_advert_timeout_s = float(
            cfg.get_from_extra_config("pd_load_advert_timeout_s", 0.0)
        )
        self._load_xfer_timeout_s = float(
            cfg.get_from_extra_config("pd_load_xfer_timeout_s", 10.0)
        )
        # pd_async_load: prefetch the NIXL READ in the background (off the engine step). Passed
        # via extra_config (the env var is stripped from the curated EngineCore spawn — same
        # reason EPD_TRACE needs a marker file). Default OFF.
        _al = cfg.get_from_extra_config("pd_async_load", False)
        self._async_load = (_al is True) or (str(_al).lower() in ("1", "true", "yes", "on"))
        # Worker-side transfer core; built lazily once the runner knows KV geometry
        # (register_runtime) — the rebel runtime can't be safely probed at init.
        self.core: PdNixlKvCore | None = None
        self._copy_op = None
        # Scheduler-role state: pd params parsed from request.kv_transfer_params, and
        # the consumer blocks allocated for each remote-KV request.
        self._pd_params: dict[str, dict] = {}
        self._consumer_blocks: dict[str, list[int]] = {}
        logger.info(
            "[EPD] PdNixlKvConnector init role=%s kv_role=%s host=%s port=%s targets=%s",
            role, self._kv_role, self._host, self._port, list(self._targets.keys()),
        )

    # ------------------------------------------------------------------
    # Custom wiring driven by the optimum runner (the real transfer path)
    # ------------------------------------------------------------------
    def _core_role(self) -> str:
        return "consumer" if self._kv_role == "kv_consumer" else "producer"

    def register_runtime(
        self,
        layer_names: list,
        num_blocks: int,
        block_numel: int,
        dtype: torch.dtype,
        block_size_tok: int = 0,
        head_dim: int = 0,
    ) -> None:
        """Called by the optimum runner during initialize_kv_cache (worker role)."""
        if self.role != KVConnectorRole.WORKER:
            return
        self.core = PdNixlKvCore(
            self._core_role(), str(self._engine_id), layer_names,
            num_blocks, block_numel, dtype, self._host, self._port,
            block_size_tok=block_size_tok, targets=self._targets, head_dim=head_dim,
            async_load=self._async_load,
        )
        if self._copy_op is not None:
            self.core.set_copy_op(self._copy_op)
            # [EPD] serve-time byte-equal GATE (default-OFF). Proves the all-layers
            # update_kv_cache(None) path == the per-layer named path on the REAL runtime
            # before we trust the optimized h2d. Does not touch the hot path. Gated by env
            # OR a marker file (vLLM curates the EngineCore env, so env alone may not reach it).
            _selftest_on = (
                os.getenv("EPD_KV_ALLLAYERS_SELFTEST", "0") not in ("0", "", "false", "False")
                or os.path.exists("/workspace/EPD_Disagg/logs/epd_kv_selftest")
            )
            if _selftest_on:
                try:
                    # sz=256 so the chunked-path byte check exercises real block_offset>0 sub-chunks
                    self.core.selftest_alllayers(size_tok=256)
                except Exception as e:  # never break bring-up on a diagnostic
                    logger.error("[EPD] KV all-layers self-test ERROR: %s", e, exc_info=True)
        logger.info(
            "[EPD] PdNixlKvConnector.register_runtime core=%s layers=%d num_blocks=%d numel=%d",
            self._core_role(), len(layer_names), num_blocks, block_numel,
        )

    def set_host_xfer_buffer_ops(self, copy_operation) -> None:
        """Runner-provided d2h/h2d op: copy_op(pool_full_layer, rebel_blk, size, layer, dir)."""
        self._copy_op = copy_operation
        if self.core is not None:
            self.core.set_copy_op(copy_operation)

    def publish_kv(self, pd_key: str, block_ids: list, rope_delta: float = 0.0,
                   dst: str | None = None, num_tokens: int = 0, num_images: int = 0) -> None:
        assert self.core is not None
        self.core.publish_kv(pd_key, block_ids, rope_delta=rope_delta, dst=dst,
                             num_tokens=num_tokens, num_images=num_images)

    def load_kv(self, pd_key: str, producer_block_ids: list, consumer_block_ids: list,
                num_tokens: int = 0, num_images: int = 0):
        """Returns (ok, rope_delta)."""
        assert self.core is not None
        return self.core.load_kv(pd_key, producer_block_ids, consumer_block_ids,
                                 num_tokens=num_tokens, num_images=num_images)

    # ------------------------------------------------------------------
    # Worker-side: drive transfers from the bound per-step connector metadata.
    # The optimum runner calls do_save() after a prefill forward and do_load()
    # before a decode-from-KV forward (both transfer-time = safe for the runtime).
    # ------------------------------------------------------------------
    def do_save(self, rope_lookup) -> list:
        """Producer: publish KV for every req in reqs_to_save. rope_lookup(req_id)->float.
        Returns the list of (req_id, pd_key) published."""
        if self.core is None:
            return []
        meta = self._get_connector_metadata()
        published = []
        for req_id, vals in getattr(meta, "reqs_to_save", {}).items():
            pd_key, block_ids = vals[0], vals[1]
            pd_dst = vals[2] if len(vals) > 2 else None
            ntok = vals[3] if len(vals) > 3 else 0
            n_img = vals[4] if len(vals) > 4 else 0
            rope = 0.0
            try:
                rope = float(rope_lookup(req_id))
            except Exception:
                rope = 0.0
            self.core.publish_kv(pd_key, block_ids, rope_delta=rope, dst=pd_dst,
                                 num_tokens=ntok, num_images=n_img)
            published.append((req_id, pd_key))
            logger.info("[EPD] do_save published req=%s key=%s dst=%s blocks=%s rope=%s ntok=%s n_img=%s",
                        req_id, pd_key, pd_dst, block_ids, rope, ntok, n_img)
        return published

    def do_load(self) -> dict:
        """Consumer: NIXL-READ KV for every req in reqs_to_load.
        Returns {req_id: (ok, rope_delta)}."""
        out: dict[str, tuple] = {}
        if self.core is None:
            return out
        meta = self._get_connector_metadata()
        for req_id, vals in getattr(meta, "reqs_to_load", {}).items():
            pd_key, cblocks = vals[0], vals[1]
            ntok = vals[2] if len(vals) > 2 else 0
            n_img = vals[3] if len(vals) > 3 else 0
            ok, rope = self.core.load_kv(
                pd_key, list(cblocks), list(cblocks),
                timeout=self._load_xfer_timeout_s,
                advert_timeout=self._load_advert_timeout_s,
                num_tokens=ntok,
                num_images=n_img,
            )
            out[req_id] = (ok, rope)
            logger.info("[EPD] do_load req=%s key=%s blocks=%s ntok=%s n_img=%s ok=%s rope=%s",
                        req_id, pd_key, cblocks, ntok, n_img, ok, rope)
        return out

    # ------------------------------------------------------------------
    # Worker-side ABC methods — no-ops (optimum forward has no per-layer hooks)
    # ------------------------------------------------------------------
    def start_load_kv(self, forward_context: "ForwardContext", **kwargs: Any) -> None:
        return

    def wait_for_layer_load(self, layer_name: str) -> None:
        return

    def save_kv_layer(self, layer_name: str, kv_layer: torch.Tensor,
                      attn_metadata: Any, **kwargs: Any) -> None:
        return

    def wait_for_save(self) -> None:
        return

    def register_kv_caches(self, kv_caches: dict[str, torch.Tensor]) -> None:
        # Intentionally NOT the stock path (would need vLLM attn-backends/KV layout).
        return

    # ------------------------------------------------------------------
    # Scheduler-side ABC methods — minimal defaults (filled in Step 3/4)
    # ------------------------------------------------------------------
    @staticmethod
    def _pd_of(request: "Request") -> dict:
        p = getattr(request, "kv_transfer_params", None)
        return p if isinstance(p, dict) else {}

    def get_num_new_matched_tokens(
        self, request: "Request", num_computed_tokens: int
    ) -> tuple[int | None, bool]:
        """Consumer: report prompt_len-1 tokens as remotely available (synchronous load,
        no WAITING_FOR_REMOTE_KVS park). Producer/normal: 0. Records pd params either way."""
        p = self._pd_of(request)
        role = p.get("pd_role")
        key = p.get("pd_key")
        if not role or not key:
            return 0, False
        self._pd_params[request.request_id] = p
        if role == "consumer":
            prompt_len = len(request.prompt_token_ids)
            n_ext = max(0, prompt_len - 1)
            return n_ext, False
        return 0, False

    def update_state_after_alloc(
        self, request: "Request", blocks: "KVCacheBlocks", num_external_tokens: int
    ) -> None:
        p = self._pd_params.get(request.request_id)
        if not p or p.get("pd_role") != "consumer":
            return
        try:
            bids = blocks.get_block_ids()
            block_ids = list(bids[0]) if isinstance(bids, (tuple, list)) else list(bids)
        except Exception:
            block_ids = []
        self._consumer_blocks[request.request_id] = block_ids

    def build_connector_meta(self, scheduler_output: "SchedulerOutput") -> KVConnectorMetadata:
        meta = PdNixlKvConnectorMetadata()
        for nr in scheduler_output.scheduled_new_reqs:
            p = self._pd_params.get(nr.req_id)
            if not p:
                continue
            key = p.get("pd_key")
            role = p.get("pd_role")
            new_blocks = list(nr.block_ids[0]) if nr.block_ids else []
            # valid KV token count = prefill length (incl. expanded image tokens). Producer
            # and consumer see the SAME prompt -> same num_tokens -> matching compact buffers.
            ntok = getattr(nr, "num_tokens", None)
            if ntok is None:
                ntok = len(getattr(nr, "prompt_token_ids", []) or [])
            ntok = int(ntok or 0)
            # [EPD] per-request image count -> interim multi-image guard in the core (keeps the
            # all-layers None KV op off for multi-image, which aborts the device). mm_features has
            # one entry per multimodal item on THIS engine's scheduler output; P and D gate
            # independently (the wire buffer is layout-identical for both KV paths).
            n_img = len(getattr(nr, "mm_features", None) or [])
            if role == "producer":
                pd_dst = p.get("pd_dst")
                meta.reqs_to_save[nr.req_id] = (key, new_blocks, pd_dst, ntok, n_img)
            elif role == "consumer":
                cblocks = self._consumer_blocks.get(nr.req_id) or new_blocks
                meta.reqs_to_load[nr.req_id] = (key, cblocks, ntok, n_img)
        return meta

    def request_finished(
        self, request: "Request", block_ids: list[int]
    ) -> tuple[bool, dict[str, Any] | None]:
        # Drop scheduler-side state for the finished request. The proxy already owns
        # pd_key, so no kv_transfer_params need to be returned. Producer host buffers
        # are released by the worker (core.release) once the consumer has pulled.
        self._pd_params.pop(request.request_id, None)
        self._consumer_blocks.pop(request.request_id, None)
        return False, None

    def shutdown(self) -> None:
        if self.core is not None:
            self.core.close()
            self.core = None
