"""PdNixlKvCore — framework-free KV transfer orchestration for the optimum path.

Sits between the vLLM connector shell (pd_nixl_kv.py) and the transport
(pd_nixl_transport.py). Owns:
  - a FULL-LAYER host pool per KV layer (Error-1 contract: _fetch/_update index block_idx
    into a [num_blocks, *per_block] buffer), and
  - gather/scatter + per-request exact-address transfer with producer->consumer block remap.

Producer (prefill): publish_kv(req_id, block_ids)
  d2h each block into the host pool, gather the request's blocks into a contiguous xfer buffer,
  advertise it under req_id.
Consumer (decode): load_kv(req_id, producer_block_ids, consumer_block_ids)
  pull the contiguous xfer buffer, scatter into the host pool at the CONSUMER block ids, h2d.

The copy op (d2h/h2d) is injected by the runner and must call the rebel runtime
(_fetch_kv_cache / _update_kv_cache) with the FULL-LAYER pool tensor + vllm_to_rebel(block_id).
This module is NPU/vLLM-free so it is unit-testable with a fake runtime + real NIXL.
"""
from __future__ import annotations

import math
import os
import sys
from pathlib import Path

import torch

sys.path.insert(0, str(Path(__file__).resolve().parent))
from pd_nixl_transport import PdNixlConsumer, PdNixlProducer

# Tracing (optional). Mirror pd_nixl_transport: resolve epd_trace whether this file runs
# adjacent (src/) or as the installed vllm_rbln copy. Re-use src.epd_trace if already
# imported (tests) to avoid module aliasing.
try:
    for _p in (str(Path(__file__).resolve().parent), "/workspace/EPD_Disagg/src"):
        if _p not in sys.path:
            sys.path.insert(0, _p)
    import epd_trace as _epd_trace_mod
    _epd_trace_mod = sys.modules.get("src.epd_trace", _epd_trace_mod)
    def _trace_emit(name, **kw):
        return _epd_trace_mod.emit(name, **kw)
    def _trace_on():
        return _epd_trace_mod.enabled()
    def _trace_now():
        return _epd_trace_mod.now_mono()
except Exception:
    def _trace_emit(name, **kw):  # type: ignore[misc]
        pass
    def _trace_on():  # type: ignore[misc]
        return False
    def _trace_now():  # type: ignore[misc]
        return 0.0

try:
    from vllm_rbln.logger import init_logger
    logger = init_logger(__name__)
except Exception:  # framework-free fallback (standalone unit tests)
    import logging
    logger = logging.getLogger(__name__)

NULL_BLOCK = 0


def vllm_to_rebel(block_id: int) -> int:
    assert block_id >= 1, f"block 0 is the null block; got {block_id}"
    return block_id - 1


class PdNixlKvCore:
    def __init__(
        self,
        role: str,                 # "producer" | "consumer"
        engine_id: str,
        layer_names: list,         # KV layer names for the copy op (or [None] for all-layers)
        num_blocks: int,
        block_numel: int,          # elements per (block) across all layers (layer_name=None)
        dtype: torch.dtype,
        host: str,
        port: int,
        block_size_tok: int = 0,   # rebel `size` arg for _fetch/_update (block tokens). 0 -> block_numel
        targets: dict | None = None,  # producer: {dst_id: (host, port)} multi-decode routing
        head_dim: int = 0,         # per-block layout is [kv_heads, block_size, head_dim]; need
                                   # head_dim for the STRIDED valid-token gather (0 -> full-block).
        async_load: bool = False,  # consumer: prefetch the NIXL READ off the engine step.
    ):
        self.role = role
        self.engine_id = engine_id
        self.layer_names = layer_names
        self.num_blocks = num_blocks
        self.block_numel = block_numel
        self.dtype = dtype
        self.head_dim = int(head_dim)
        # rebel _fetch/_update want the in-block token count as `size` (validated: 8192),
        # NOT the element count. Fall back to block_numel for the fake-runtime unit test.
        self.block_size_tok = block_size_tok or block_numel
        # [EPD] all-layers h2d (flag-gated, default-OFF; gate-proven byte-equal on TP4): the
        # consumer integrates incoming KV with ONE update_kv_cache(layer_name=None) per block
        # (1 dispatch) instead of 72 per-(block,layer) named calls (~41ms -> ~2ms admit bubble).
        # The None path iterates layers in mem_name (alphabetical) order, so the host buffer must
        # be one CONTIGUOUS [L, num_blocks, block_numel] block laid out in sorted(layer_names);
        # per-layer views feed the existing scatter unchanged. Marker OR env (vLLM curates the
        # EngineCore env, so a marker file is the reliable channel).
        # SINGLE-IMAGE / TEXT ONLY. The all-layers None KV op (both update h2d and fetch d2h)
        # aborts the device (SYS_TASK_ABORTED) under MULTI-IMAGE serving — proven in matrix5 on
        # both producer and consumer, single-block, ntok well within the sweep-safe range, so it is
        # NOT size/open-loop/block-count. The abort is inside the rebel runtime's all-layers op in
        # the multi-image context (not patchable from the connector); per-layer is robust. There is
        # no clean multi-image signal here to auto-gate on, so the flag MUST stay OFF for any
        # multi-image workload. Validated ON for text (m1) and single-image (m4). See kv-alllayers-fix.md.
        self._alllayers = (
            role in ("consumer", "producer") and len(layer_names) > 1
            and all(n is not None for n in layer_names)
            and (os.getenv("EPD_KV_ALLLAYERS", "0") not in ("0", "", "false", "False")
                 or os.path.exists("/workspace/EPD_Disagg/logs/epd_kv_alllayers"))
        )
        # [EPD] interim multi-image guard: a request with MORE images than this keeps the SAFE
        # per-layer named KV path even when all-layers is enabled. The all-layers None device op
        # aborts (SYS_TASK_ABORTED) under multi-image serving — root cause is the dependency-free
        # KV dispatch racing in-flight model jobs on the device (rebel kv_cache.cc Dispatch), not
        # the host packing. Default 1 = text + single-image keep the fast path (validated scope
        # m1/m4); set EPD_KV_ALLLAYERS_MAX_IMAGES=0 to also drop single-image to per-layer.
        self._alllayers_max_images = int(os.getenv("EPD_KV_ALLLAYERS_MAX_IMAGES", "1"))
        self.pool_contig = None
        # full-layer host pool per layer: [num_blocks, block_numel]. ALIGNED for rebel DMA
        # (the stock connector uses aligned_tensor; required by _fetch/_update on device).
        try:
            from rebel.kv_cache import aligned_tensor
            if self._alllayers:
                base = aligned_tensor(
                    len(layer_names) * num_blocks * block_numel, tensor_type="pt"
                ).view(len(layer_names), num_blocks, block_numel)
                self.pool_contig = base
                self.pool = {ln: base[j] for j, ln in enumerate(sorted(layer_names))}
            else:
                self.pool = {
                    ln: aligned_tensor(num_blocks * block_numel, tensor_type="pt").view(num_blocks, block_numel)
                    for ln in layer_names
                }
        except Exception:
            self.pool = {
                ln: torch.zeros(num_blocks, block_numel, dtype=dtype).contiguous()
                for ln in layer_names
            }
            self._alllayers = False
            self.pool_contig = None
        self._copy_op = None  # injected: copy_op(pool_tensor, block_id, size, layer, direction)
        if role == "producer":
            self.endpoint = PdNixlProducer(engine_id, host, port, targets=targets)
        else:
            self.endpoint = PdNixlConsumer(engine_id, host, port, async_load=async_load)

    def set_copy_op(self, copy_op) -> None:
        """copy_op(pool_tensor_full_layer, rebel_block_idx, size, layer_name, direction)."""
        self._copy_op = copy_op

    def _alloc_pool_like(self, n_layers: int = 1):
        """Aligned [n_layers, num_blocks, block_numel] host buffer, mirroring the pool's
        allocation (rebel DMA needs the 0x1000 alignment)."""
        try:
            from rebel.kv_cache import aligned_tensor
            t = aligned_tensor(n_layers * self.num_blocks * self.block_numel, tensor_type="pt")
        except Exception:
            t = torch.zeros(n_layers * self.num_blocks * self.block_numel, dtype=self.dtype)
        return t.view(n_layers, self.num_blocks, self.block_numel)

    def selftest_alllayers(self, size_tok: int = 16) -> bool:
        """[EPD serve-time GATE — default-OFF via EPD_KV_ALLLAYERS_SELFTEST] On the REAL
        (TP) runtime, prove that ONE update_kv_cache(layer_name=None) over the
        mem_name-SORTED concat buffer lands byte-identically to the current
        per-(block,layer) named path. Runs once on a scratch block before traffic and
        restores it. Returns True on PASS. Does NOT touch the h2d hot path."""
        names = list(self.layer_names)
        if (len(names) <= 1 or any(n is None for n in names) or self._copy_op is None):
            logger.info("[EPD] KV all-layers self-test: SKIP (role=%s layers=%d)",
                        self.role, len(names))
            return True
        op = self._copy_op
        S = self.num_blocks - 1                       # scratch rebel block (unused pre-traffic)
        sz = max(1, min(int(size_tok), self.block_size_tok))
        bn = self.block_numel
        # runtime iterates layers in mem_name (alphabetical) order, NOT numeric:
        # "past_key_values_10" < "past_key_values_2". The None concat MUST match that.
        sorted_names = sorted(names)
        L = len(names)

        def fill(i):                                  # exact-in-fp16/bf16 distinct ramp in block S
            t = self._alloc_pool_like(1)[0]
            t[S] = ((torch.arange(bn, dtype=torch.int32) * 31 + i * 17) % 200).to(t.dtype)
            return t

        src = {ln: fill(i) for i, ln in enumerate(names)}
        zero = self._alloc_pool_like(1)[0]

        # Path A: current per-(block,layer) named writes -> read back per layer.
        for ln in names:
            op(src[ln], S, sz, ln, "h2d")
        A = {}
        for ln in names:
            o = self._alloc_pool_like(1)[0]
            op(o, S, sz, ln, "d2h")
            A[ln] = o[S].clone()
        # d2h all-layers (producer kv_gather path): ONE fetch_kv_cache(None) over the sorted
        # concat must match the per-layer named d2h reads, layer-for-layer.
        cread = self._alloc_pool_like(L)
        op(cread, S, sz, None, "d2h")
        C = {ln: cread[j, S].clone() for j, ln in enumerate(sorted_names)}
        # [EPD] chunked all-layers d2h (block_offset stepping, the never-before-exercised
        # non-zero-offset path) must byte-match the full single None read.
        cread_ck = self._alloc_pool_like(L)
        _csz = self._align_chunk(max(1, sz // 4))   # aligned so block_offset is device-legal
        _off = 0
        while _off < sz:
            _cl = min(_csz, sz - _off) if _csz else (sz - _off)
            op(cread_ck, S, _cl, None, "d2h", _off)
            _off += _cl
        Cck = {ln: cread_ck[j, S].clone() for j, ln in enumerate(sorted_names)}
        for ln in names:                              # reset device scratch block
            op(zero, S, sz, ln, "h2d")

        # Path B: ONE all-layers None write over the sorted concat -> read back per layer.
        concat = self._alloc_pool_like(L)
        for j, ln in enumerate(sorted_names):
            concat[j, S] = src[ln][S]
        op(concat, S, sz, None, "h2d")
        B = {}
        for ln in names:
            o = self._alloc_pool_like(1)[0]
            op(o, S, sz, ln, "d2h")
            B[ln] = o[S].clone()

        for ln in names:                              # cleanup scratch block
            op(zero, S, sz, ln, "h2d")

        def region(buf):
            # compare only the bytes the strided write actually touched: [kv_heads,:sz,head_dim]
            if self.head_dim and self._kv_heads:
                return buf.view(self._kv_heads, self.block_size_tok, self.head_dim)[:, :sz, :].reshape(-1)
            return buf[: sz * self._per_token]

        named_ok = [ln for ln in names if torch.equal(region(A[ln]), region(src[ln][S]))]
        match_h2d = [ln for ln in names if torch.equal(region(A[ln]), region(B[ln]))]   # update(None)
        match_d2h = [ln for ln in names if torch.equal(region(A[ln]), region(C[ln]))]   # fetch(None)
        match_chunk = [ln for ln in names if torch.equal(region(C[ln]), region(Cck[ln]))]  # chunked==full
        mism = [ln for ln in names if ln not in match_h2d or ln not in match_d2h or ln not in match_chunk]
        ok = (len(named_ok) == L) and (len(match_h2d) == L) and (len(match_d2h) == L) and (len(match_chunk) == L)
        logger.info(
            "[EPD] KV all-layers self-test: %s  role=%s layers=%d sz=%d order=[%s..%s] "
            "named_roundtrip_ok=%d/%d h2d_none_matches=%d/%d d2h_none_matches=%d/%d "
            "chunked_matches=%d/%d mismatch=%s",
            "PASS" if ok else "FAIL", self.role, L, sz, sorted_names[0], sorted_names[-1],
            len(named_ok), L, len(match_h2d), L, len(match_d2h), L, len(match_chunk), L, mism[:5],
        )
        return ok

    # ---- helpers ----
    @property
    def _per_token(self) -> int:
        # elements per token within a layer-block (kv_heads*head_dim). block_numel = bs*per_token.
        return self.block_numel // self.block_size_tok if self.block_size_tok else self.block_numel

    @property
    def _kv_heads(self) -> int:
        # block_numel = kv_heads * block_size * head_dim -> kv_heads = block_numel/(bs*head_dim)
        if not self.head_dim or not self.block_size_tok:
            return 0
        return self.block_numel // (self.block_size_tok * self.head_dim)

    def _use_strided(self, num_tokens: int) -> bool:
        """Valid-token transfer needs the [kv_heads, block_size, head_dim] layout (head-major),
        so a token is strided, not a contiguous prefix. Requires head_dim; else full-block."""
        return bool(num_tokens and num_tokens > 0 and self.head_dim and self._kv_heads)

    def _gather_block(self, ln, rb: int, v: int):
        """Compact, contiguous copy of the first v tokens of pool[ln][rb] in [kv_heads, v,
        head_dim] order (strided slice of the head-major block)."""
        view = self.pool[ln][rb].view(self._kv_heads, self.block_size_tok, self.head_dim)
        return view[:, :v, :].reshape(-1).to(self.dtype)

    def _scatter_block(self, ln, rb: int, v: int, piece) -> None:
        view = self.pool[ln][rb].view(self._kv_heads, self.block_size_tok, self.head_dim)
        view[:, :v, :] = piece.view(self._kv_heads, v, self.head_dim).to(view.dtype)

    def _valid_tokens(self, n_blocks: int, num_tokens: int) -> list:
        """Valid token count per block. num_tokens<=0 -> full block (legacy, byte-compatible)."""
        bs = self.block_size_tok
        if not num_tokens or num_tokens <= 0:
            return [bs] * n_blocks
        return [max(0, min(bs, num_tokens - i * bs)) for i in range(n_blocks)]

    # All-layers single DMA aborts (SYS_TASK_ABORTED) for large prefills under serving — the d2h
    # reads the KV the in-flight forward is still writing (the KV write is a prefill graph SINK,
    # un-drainable from Python). Chunking the TOKEN range (block_offset stepping, all 72 layers per
    # chunk, one Dispatch+Wait each) keeps each job small enough to coexist with the forward, while
    # staying far below the 72-dispatch per-layer fallback. Validated on pd_tp2_4p4d: byte-equal
    # (self-test chunked_matches=72/72) and abort-free at conc24 for text/image/long-decode at
    # chunk<=512 (chunk 1024 ok @conc4; 2048 aborts). 512 tok => 8 dispatches for a 4000-tok prefill.
    DEFAULT_CHUNK_TOK = 512

    def _chunk_tok(self) -> int:
        """Token-chunk size for the all-layers None d2h/h2d. DEFAULT_CHUNK_TOK unless overridden by
        the marker file (read PER-CALL so it can be swept without restarting the curated-env
        EngineCore). Marker value 0 disables chunking (single DMA — unsafe for large prefills)."""
        try:
            with open("/workspace/EPD_Disagg/logs/epd_kv_chunk_tok") as f:
                return max(0, int((f.read().strip() or str(self.DEFAULT_CHUNK_TOK))))
        except Exception:
            return self.DEFAULT_CHUNK_TOK

    def _copy_alllayers(self, rb: int, v: int, direction: str) -> int:
        """All-layers None copy of one block, optionally split into _chunk_tok token-chunks
        (each chunk = all 72 layers for a token sub-range via block_offset). Returns dispatches."""
        chunk = self._align_chunk(self._chunk_tok())
        if chunk and 0 < chunk < v:
            off = 0
            n = 0
            while off < v:
                clen = min(chunk, v - off)
                # block_offset (=off) is always a multiple of `chunk`, which _align_chunk made a
                # multiple of `align` -> its byte offset (off*head_dim*2) stays 0x1000-aligned, which
                # the runtime requires (non-aligned block_offset -> SYS_ERROR -22). clen (copy_size)
                # need not be aligned (the valid-token path already uses arbitrary sizes).
                self._copy_op(self.pool_contig, rb, clen, None, direction, off)
                off += clen
                n += 1
            return n
        self._copy_op(self.pool_contig, rb, v, None, direction)
        return 1

    def _align_chunk(self, chunk: int) -> int:
        """Round a token-chunk DOWN to the largest multiple of `align` (>= align), where align makes
        block_offset*head_dim*2 a multiple of 0x1000. Returns 0 (no chunking) if chunk<=0 or head_dim
        unknown. This guarantees every block_offset the chunk loop produces is device-legal."""
        if not chunk or not self.head_dim:
            return 0
        align = 4096 // math.gcd(4096, self.head_dim * 2)
        return max(align, (chunk // align) * align)

    # ---- producer ----
    def publish_kv(self, request_id: str, block_ids: list, rope_delta: float = 0.0,
                   dst: str | None = None, num_tokens: int = 0, num_images: int = 0) -> None:
        assert self.role == "producer"
        assert self._copy_op is not None
        per_tok = self._per_token
        strided = self._use_strided(num_tokens)
        valids = self._valid_tokens(len(block_ids), num_tokens)
        _t = _trace_now() if _trace_on() else None
        # d2h: device block -> pool[block]. size=v fetches only the valid tokens of the block.
        if self.pool_contig is not None and num_images <= self._alllayers_max_images:
            # [EPD] all-layers d2h into the sorted-mem_name contiguous pool. Optionally token-
            # chunked (_chunk_tok marker) to issue smaller jobs vs the single 72-layer DMA that
            # aborts on large prefills. The gather below reads per-layer views (numeric order).
            _disp = 0
            for bid, v in zip(block_ids, valids):
                _disp += self._copy_alllayers(vllm_to_rebel(bid), v, "d2h")
        else:
            for bid, v in zip(block_ids, valids):
                rb = vllm_to_rebel(bid)
                for ln in self.layer_names:
                    self._copy_op(self.pool[ln], rb, v, ln, "d2h")
            _disp = len(block_ids) * len(self.layer_names)
        # gather valid-token KV (block-major, then layer) into a compact contiguous buffer.
        # Cast to self.dtype so the wire format matches the consumer's flat buffer (the pool may
        # be float16 via aligned_tensor while self.dtype is float32 — mirror the legacy cast).
        # NOTE: a torch.cat-elimination (preallocate + direct write) was tried 2026-06-24 and
        # REVERTED — byte-identical buffer (CPU-proven) but it regressed HW success_rate to 0.333
        # (a pull/handshake timing effect), and the cat was only ~1ms of the ~12ms kv_gather span
        # (the residual is the strided gather-read copy + d2h, not the cat). Not worth the risk.
        parts = []
        for bid, v in zip(block_ids, valids):
            rb = vllm_to_rebel(bid)
            for ln in self.layer_names:
                if strided:
                    parts.append(self._gather_block(ln, rb, v))
                else:
                    parts.append(self.pool[ln][rb][:v * per_tok].to(self.dtype))
        buf = torch.cat(parts).contiguous() if parts else torch.zeros(0, dtype=self.dtype)
        if _t is not None:
            _trace_emit("kv_gather", track=f"P{self.engine_id}", ph="X", ts=_t,
                        dur=_trace_now() - _t,
                        args={"request_id": request_id, "blocks": len(block_ids),
                              "layers": len(self.layer_names), "dispatches": _disp})
        self.endpoint.publish(request_id, buf, rope_delta=rope_delta, dst=dst,
                              num_tokens=int(num_tokens))

    def release(self, request_id: str) -> None:
        if self.role == "producer":
            self.endpoint.release(request_id)

    # ---- consumer ----
    def load_kv(
        self,
        request_id: str,
        producer_block_ids: list,
        consumer_block_ids: list,
        timeout: float = 10.0,
        advert_timeout: float | None = None,
        num_tokens: int = 0,
        num_images: int = 0,
    ):
        """Pull the request's KV (NIXL READ), scatter into consumer blocks, h2d.

        Only the valid tokens (num_tokens) are transferred; num_tokens<=0 falls back to
        full-block (byte-compatible with the legacy path). The consumer computes the same
        per-block valid split as the producer (identical prompt -> identical num_tokens),
        so the compact buffer size matches exactly.

        Returns (ok: bool, rope_delta: float). On failure returns (False, 0.0).
        """
        assert self.role == "consumer"
        assert self._copy_op is not None
        assert len(producer_block_ids) == len(consumer_block_ids)
        per_tok = self._per_token
        strided = self._use_strided(num_tokens)
        valids = self._valid_tokens(len(consumer_block_ids), num_tokens)
        total = sum(v * per_tok for v in valids) * len(self.layer_names)
        # `empty`, not `zeros`: the NIXL READ overwrites the WHOLE buffer (transport asserts
        # nbytes == flat.numel()*element_size()) and the scatter consumes every element, so the
        # memset is pure waste on the critical path — ~100ms for a 1.2GB large-prompt transfer.
        flat = torch.empty(total, dtype=self.dtype).contiguous()
        if not self.endpoint.pull(request_id, flat, timeout=timeout,
                                  advert_timeout=advert_timeout):
            return False, 0.0
        rope_delta = self.endpoint.get_rope_delta(request_id)
        track = f"D{self.engine_id}"
        # scatter compact buffer (block-major, then layer) into consumer pool, then h2d
        _t = _trace_now() if _trace_on() else None
        off = 0
        for cbid, v in zip(consumer_block_ids, valids):
            rb = vllm_to_rebel(cbid)
            seg = v * per_tok
            for ln in self.layer_names:
                piece = flat[off:off + seg]
                if strided:
                    self._scatter_block(ln, rb, v, piece)
                else:
                    self.pool[ln][rb][:seg] = piece
                off += seg
        if _t is not None:
            _trace_emit("kv_scatter", track=track, ph="X", ts=_t, dur=_trace_now() - _t,
                        args={"request_id": request_id, "blocks": len(consumer_block_ids),
                              "layers": len(self.layer_names)})
        _t = _trace_now() if _trace_on() else None
        if self.pool_contig is not None and num_images <= self._alllayers_max_images:
            # [EPD] all-layers h2d over the sorted-mem_name contiguous pool (scatter above wrote it
            # via per-layer views). Optionally token-chunked (_chunk_tok marker), same as d2h.
            _disp = 0
            for cbid, v in zip(consumer_block_ids, valids):
                _disp += self._copy_alllayers(vllm_to_rebel(cbid), v, "h2d")
        else:
            for cbid, v in zip(consumer_block_ids, valids):
                rb = vllm_to_rebel(cbid)
                for ln in self.layer_names:
                    self._copy_op(self.pool[ln], rb, v, ln, "h2d")
            _disp = len(consumer_block_ids) * len(self.layer_names)
        if _t is not None:
            _trace_emit("kv_h2d", track=track, ph="X", ts=_t, dur=_trace_now() - _t,
                        args={"request_id": request_id, "blocks": len(consumer_block_ids),
                              "layers": len(self.layer_names), "dispatches": _disp})
        return True, rope_delta

    def close(self) -> None:
        self.endpoint.close()
