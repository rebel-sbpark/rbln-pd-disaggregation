#!/usr/bin/env bash
# PD-disaggregation 코드(vllm_rbln overlay)를 설치된 vllm_rbln 위에 덮어쓴다.
# producer 박스, consumer 박스 양쪽에서 각각 한 번씩 실행.
#   VENV=/workspace/benchmark/.venv bash install.sh
set -euo pipefail
VENV="${VENV:-/workspace/benchmark/.venv}"
HERE="$(cd "$(dirname "$0")" && pwd)"

[ -x "$VENV/bin/python" ] || { echo "FATAL: venv 없음: $VENV (VENV=... 로 지정)"; exit 2; }

TARGET="$("$VENV/bin/python" - <<'PY'
import os, importlib.util
spec = importlib.util.find_spec("vllm_rbln")
assert spec and spec.submodule_search_locations, "vllm_rbln 이 설치돼 있지 않음 (pip install vllm_rbln 먼저)"
print(spec.submodule_search_locations[0])
PY
)"
echo "[install] vllm_rbln 위치: $TARGET"

# 덮어쓰기 전 백업(최초 1회)
BK="$TARGET.pre_pd_bak"
[ -d "$BK" ] || { cp -r "$TARGET" "$BK"; echo "[install] 백업 생성: $BK"; }

cp -rv "$HERE/vllm_rbln_overlay/vllm_rbln/." "$TARGET/" >/dev/null
echo "[install] overlay 적용 완료."

# 필수 런타임 의존성 확인
"$VENV/bin/python" - <<'PY'
missing=[]
for m in ("torch","msgspec","zmq","nixl"):
    try: __import__(m)
    except Exception as e: missing.append(f"{m} ({e})")
print("[install] deps OK" if not missing else "[install] MISSING: "+", ".join(missing))
PY

# pd_nixl 모듈이 실제 import 되는지 스모크
"$VENV/bin/python" - <<'PY'
import sys, importlib.util
v1 = importlib.util.find_spec("vllm_rbln").submodule_search_locations[0] + "/distributed/kv_transfer/kv_connector/v1"
sys.path.insert(0, v1)
from pd_nixl_kv_core import PdNixlKvCore  # noqa
print("[install] pd_nixl_kv_core import OK -> 설치 성공")
PY
echo "[install] 완료. 다음: consumer 박스에서 run_consumer.sh, producer 박스에서 run_producer.sh"
