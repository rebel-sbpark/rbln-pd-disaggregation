#!/usr/bin/env bash
# RBLN NPU decode pool: N x TP decode consumers, each running the multi-batch decode artifact as a
# kv_consumer that receives KV from a producer over pd_nixl (NIXL/UCX + ZMQ). CPU pinning on.
# Model-agnostic: set MODEL_DIR (a decode-pool artifact from compile_decode_pool.py) and the topology.
#   MODEL_DIR=/path/to/decodepool-artifact N_DECODERS=8 TP=2 bash run_consumer_npu.sh
set -euo pipefail
VENV="${VENV:-/workspace/benchmark/.venv}"
MODEL_DIR="${MODEL_DIR:?set MODEL_DIR to a decode-pool artifact (see compile_decode_pool.py)}"
N_DECODERS="${N_DECODERS:-8}"        # N x TP must fit the available cards (N*TP <= card count)
TP="${TP:-2}"                        # must divide the model's kv_heads
BASE_HTTP="${BASE_HTTP:-8001}"       # d0=8001, d1=8002, ...
BASE_PD="${BASE_PD:-9000}"           # pd_nixl recv port per decoder
MAX_NUM_SEQS="${MAX_NUM_SEQS:-}"     # default = largest compiled decoder batch (read from config)

# --- RBLN transport / runtime envs ---
export UCX_TLS="${UCX_TLS:-cma,tcp,self}"                                     # validated transport
export RBLN_DISABLE_EAGER_CACHE_ALLOC="${RBLN_DISABLE_EAGER_CACHE_ALLOC:-1}"  # device-VA alignment
export EPD_KV_ALLLAYERS="${EPD_KV_ALLLAYERS:-0}"                              # all-layers KV path OFF
export VLLM_USE_V1=1 RBLN_NUM_THREADS="${RBLN_NUM_THREADS:-8}"

# --- DRAM headroom guard: refuse an artifact compiled with auto (edge) KV; require explicit nb ---
MAX_NUM_SEQS="$("$VENV/bin/python" - "$MODEL_DIR" "${MAX_NUM_SEQS:-0}" <<'PY'
import json, sys
c = json.load(open(sys.argv[1] + "/rbln_config.json"))
nb = c.get("kvcache_num_blocks"); dbs = c.get("decoder_batch_sizes")
full = (c["max_seq_len"] // c["kvcache_block_size"]) * max(dbs)   # num_full_blocks (flash upper bound)
assert nb and nb > 0, "artifact compiled with auto KV blocks (DRAM edge); recompile with an explicit KVCACHE_NUM_BLOCKS below the auto-max for headroom"
if nb >= full:
    sys.stderr.write(f"[warn] kvcache_num_blocks={nb} >= num_full_blocks={full}: little/no DRAM headroom\n")
sys.stderr.write(f"[headroom] nb={nb} full_blocks={full} decode_batches={dbs}\n")
print(int(sys.argv[2]) or max(dbs))
PY
)"

# --- CPU pinning (unpinned -> host stalls starve the NPU) ---
PIN="${PIN:-1}"
pin_prefix() {  # $1 = decoder index -> taskset core range from the pinning package
  [ "$PIN" = "1" ] || { echo ""; return; }
  "$VENV/bin/python" -c "import sys; sys.path.insert(0,'/workspace/EPD_Disagg/src'); \
from pinning.pin_plan import decode_cores_for; print(decode_cores_for($1, $N_DECODERS))" 2>/dev/null \
    | sed 's/^/taskset -c /' || echo ""
}

for i in $(seq 0 $((N_DECODERS-1))); do
  d0=$((i*TP)); d1=$((d0+TP-1)); DEVS=$(seq -s, $d0 $d1)
  HTTP=$((BASE_HTTP+i)); PD=$((BASE_PD+i)); LOG="serve_decode_d${i}.log"
  KVT='{"kv_connector":"PdNixlKvConnector","kv_role":"kv_consumer","kv_buffer_device":"cpu","kv_connector_extra_config":{"pd_host":"0.0.0.0","pd_port":'"$PD"',"pd_load_advert_timeout_s":0,"pd_load_xfer_timeout_s":10.0}}'
  echo "[decode d$i] devices=$DEVS http=:$HTTP pd=:$PD log=$LOG"
  RBLN_DEVICES="$DEVS" $(pin_prefix $i) "$VENV/bin/vllm" serve "$MODEL_DIR" \
    --trust-remote-code --host 0.0.0.0 --port "$HTTP" --served-model-name decode \
    --max-num-seqs "$MAX_NUM_SEQS" --kv-transfer-config "$KVT" > "$LOG" 2>&1 &
done
echo "[consumer] launched $N_DECODERS x TP$TP decoders (d0..d$((N_DECODERS-1)))."
wait
