#!/usr/bin/env python
"""Compile an RBLN decode-pool artifact: one artifact holding several decode batch graphs, sized to
leave DRAM headroom. Model-agnostic — everything is set by env vars; nothing here assumes a model.

Env:
  MODEL_ID            (required)  HF model id or local path to compile.
  TP                  tensor-parallel size (must divide the model's kv_heads).
  MAX_SEQ_LEN         compiled max sequence length.
  PARTITION_LEN       flash-attn kv partition length (block size == partition len for flash_attn).
  DECODE_BATCHES      comma list of decode batch sizes to compile into one artifact, e.g. "32,16,8,4".
                      The runtime picks the smallest graph >= the active sequence count. Extra decode
                      graphs cost little graph memory; KV blocks are the real bound.
  KVCACHE_NUM_BLOCKS  KV blocks to allocate. 0 => auto (fills DRAM to the edge). For sustained serving
                      set it BELOW the auto-max (leave headroom) or the runtime can OOM under load.
                      Recommended: compile once with 0, read the chosen value, recompile at ~80-85%.
  SAVE_DIR            output dir (default derived from MODEL_ID + params).
  PHASES_DECODE_ONLY  =1 to request phases=["decode"] (drops the prefill *runtime*; the prefill graph
                      is still built+shipped by the optimum API — near-free at runtime).
"""
import os, time, json
from pathlib import Path

MODEL_ID = os.environ.get("MODEL_ID")
if not MODEL_ID:
    raise SystemExit("set MODEL_ID (HF id or local path)")
TP = int(os.environ.get("TP", "2"))
MAX_SEQ_LEN = int(os.environ.get("MAX_SEQ_LEN", "8192"))
PARTITION_LEN = int(os.environ.get("PARTITION_LEN", "4096"))
DECODE_BATCHES = [int(x) for x in os.environ.get("DECODE_BATCHES", "32,16,8,4").split(",")]
NB = int(os.environ.get("KVCACHE_NUM_BLOCKS", "0"))   # 0 = auto; set below auto-max for headroom
_tag = MODEL_ID.rstrip("/").split("/")[-1]
SAVE = Path(os.environ.get("SAVE_DIR",
            f"/workspace/models/{_tag}-decodepool-tp{TP}-bs{max(DECODE_BATCHES)}-nb{NB}"))


def main():
    os.environ.setdefault("RBLN_RUNTIME_TIMER", "0")
    from optimum.rbln import RBLNAutoModelForCausalLM
    SAVE.mkdir(parents=True, exist_ok=True)
    if len(list(SAVE.glob("*.rbln"))) >= 2:
        print(f"[skip] already compiled: {SAVE}"); return
    cfg = {"batch_size": max(DECODE_BATCHES), "max_seq_len": MAX_SEQ_LEN, "tensor_parallel_size": TP,
           "attn_impl": "flash_attn", "kvcache_partition_len": PARTITION_LEN,
           "decoder_batch_sizes": DECODE_BATCHES, "kvcache_num_blocks": NB}
    if os.environ.get("PHASES_DECODE_ONLY") == "1":
        cfg["phases"] = ["decode"]
    print(f"[compile-decodepool] {MODEL_ID} -> {SAVE}\n  {cfg}", flush=True)
    t0 = time.perf_counter()
    RBLNAutoModelForCausalLM.from_pretrained(model_id=MODEL_ID, export=True, trust_remote_code=True,
                                             model_save_dir=str(SAVE), rbln_config=cfg)
    c = json.load(open(SAVE / "rbln_config.json"))
    print(f"[done] {time.perf_counter()-t0:.0f}s  kvcache_num_blocks={c.get('kvcache_num_blocks')} "
          f"decoder_batch_sizes={c.get('decoder_batch_sizes')}", flush=True)

if __name__ == "__main__":
    main()
