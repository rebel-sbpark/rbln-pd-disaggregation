# pd_disagg_consumer_npu — RBLN NPU decode pool

The **decode** half of a disaggregated prefill/decode pipeline: a pool of TP decoders on RBLN NPUs
that receive prefilled KV from a producer (NPU or GPU) over pd_nixl (NIXL/UCX + ZMQ) and generate
tokens via the optimum-path decode-skip. Model-agnostic — you pick the model, TP, batch sizes, and
KV-block budget.

## How it works
Each decoder runs a multi-batch decode artifact as a `kv_consumer`. When a producer publishes a
request's KV, the connector loads it (`do_load`) and the decoder continues generation without
re-prefilling. Multiple decode batch graphs live in one artifact; the runtime picks the smallest
graph ≥ the active sequence count.

## Setup
```bash
tar xzf pd_disagg_consumer_npu.tar.gz && cd pd_disagg_consumer_npu
VENV=/workspace/benchmark/.venv bash install.sh            # apply the vllm_rbln overlay (pd_nixl)

# compile a decode-pool artifact for YOUR model (env-driven; see compile_decode_pool.py header)
MODEL_ID=<hf-id-or-path> TP=2 DECODE_BATCHES=32,16,8,4 KVCACHE_NUM_BLOCKS=<see below> \
  RBLN_DEVICES=0,1 "$VENV/bin/python" compile_decode_pool.py

# launch the pool (N x TP; pinning on)
MODEL_DIR=<the compiled artifact> N_DECODERS=8 TP=2 bash run_consumer_npu.sh
```

## Choosing the knobs (per model + card count — no universal values)
- **TP** must divide the model's `kv_heads`.
- **N_DECODERS × TP** must fit the available cards.
- **DECODE_BATCHES**: bigger batches raise aggregate throughput but per-user latency and KV pressure;
  put several in one artifact so the runtime adapts to load. Decode graphs are cheap in memory.
- **KVCACHE_NUM_BLOCKS**: KV is the DRAM bound. Compile once with `0` (auto = fills DRAM to the edge),
  read the chosen value, then **recompile at ~80–85% of it** to keep headroom — serving at the auto
  edge can OOM under sustained load. `run_consumer_npu.sh` refuses an auto-compiled (edge) artifact.
- `phases=["decode"]` (via `PHASES_DECODE_ONLY=1`) drops the prefill runtime; the prefill graph is
  still built and shipped by the optimum API (near-free at runtime).

## Envs set by the launcher (RBLN-general)
`UCX_TLS=cma,tcp,self`, `RBLN_DISABLE_EAGER_CACHE_ALLOC=1`, `EPD_KV_ALLLAYERS=0`, CPU pinning on.

## Pairs with
`pd_disagg_producer_npu` (NPU prefill) or `pd_disagg_producer_gpu` (GPU prefill). Bring the consumer
up **first** — the producer needs this box's IP and the decoders' pd_nixl ports. See `RUNBOOK.md`.
